'use client';



interface userInfo {
    name: string;
    email: string;
    image: string;
}



import { signIn, signOut } from "next-auth/react";
import Link from "next/link";
import { useCustomSession } from "../sessions";

export default function Login(){

    const {data : session, status} = useCustomSession()
   
    const redirectTo = () =>{
        sessionStorage.setItem('preUrl', window.location.href)
        window.location.href= "/login"
    }

{
    status !== 'loading' && session && session.user?.email 
    ? 
    <>
        <p>{session && session.user?.name}님 반갑습니다.</p>
        <button onClick={()=>{signOut()}}>로그아웃</button> 
    </>
    
:
        <>
         
        </>
}

    return(
        <>
       {
        session && session.user.level === 10 ? '관리자' 
        :
        session && session.user !==null && '일반회원'  
       }
        
        {session && session.user ? <button onClick={()=>{signOut()}}>로그아웃</button> 
        : 
        <>
         <Link href="/login">통합로그인</Link>
         <Link href="/register"> <p>회원가입</p></Link>
         <div className="flex max-w-7xl justify-around">
        <button onClick={()=>{signIn('kakao')}}>카카오톡</button> 
        <button onClick={()=>{signIn('github')}}>깃허브</button> 
        <button onClick={()=>{signIn('naver')}}>네이버</button> 
        <button onClick={()=>{signIn('google')}}>구글</button> 
        </div>
        </>
    }
        {/* 커스텀 마이징 하는방법은 함수안에 '원하는 사이트 입력' */}
        </>
    )
}
