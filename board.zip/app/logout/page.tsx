export default function Logout(){
    return(
        <p>로그아웃</p>
    )
}