import db from 'mysql2/promise';

const connectDB = db.createPool({
    host: 'localhost',
    user: 'root',
    password: 'wjdtjr3088',
    database: 'board'
});

export default connectDB