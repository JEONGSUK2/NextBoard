/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/not-found";
exports.ids = ["app/not-found"];
exports.modules = {

/***/ "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$":
/*!****************************************************!*\
  !*** ./node_modules/mysql2/lib/ sync ^cardinal.*$ ***!
  \****************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("bcrypt");

/***/ }),

/***/ "./request-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/request-async-storage.external");

/***/ }),

/***/ "./static-generation-async-storage.external":
/*!***************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external" ***!
  \***************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/client/components/static-generation-async-storage.external");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist\\client\\components\\action-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist\\client\\components\\action-async-storage.external.js");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist\\client\\components\\request-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist\\client\\components\\request-async-storage.external.js");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!*********************************************************************************************!*\
  !*** external "next/dist\\client\\components\\static-generation-async-storage.external.js" ***!
  \*********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist\\client\\components\\static-generation-async-storage.external.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fnot-found&page=%2Fnot-found&appPaths=&pagePath=private-next-app-dir%2Fnot-found.tsx&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fnot-found&page=%2Fnot-found&appPaths=&pagePath=private-next-app-dir%2Fnot-found.tsx&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   __next_app__: () => (/* binding */ __next_app__),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   pages: () => (/* binding */ pages),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   tree: () => (/* binding */ tree)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-page/module.compiled */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/module.compiled.js?5bc9\");\n/* harmony import */ var next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/client/components/error-boundary */ \"(rsc)/./node_modules/next/dist/client/components/error-boundary.js\");\n/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/dist/server/app-render/entry-base */ \"(rsc)/./node_modules/next/dist/server/app-render/entry-base.js\");\n/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if([\"default\",\"tree\",\"pages\",\"GlobalError\",\"originalPathname\",\"__next_app__\",\"routeModule\"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\"TURBOPACK { transition: next-ssr }\";\n\n\n// We inject the tree and pages here so that we can use them in the route\n// module.\nconst tree = {\n        children: [\n        '',\n        {\n        children: [\n          '__DEFAULT__',\n          {},\n          {\n            defaultPage: [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! next/dist/client/components/parallel-route-default */ \"(rsc)/./node_modules/next/dist/client/components/parallel-route-default.js\", 23)), \"next/dist/client/components/parallel-route-default\"],\n          }\n        ]\n      },\n        {\n        'layout': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/layout.tsx */ \"(rsc)/./app/layout.tsx\")), \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\layout.tsx\"],\n'not-found': [() => Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/not-found.tsx */ \"(rsc)/./app/not-found.tsx\")), \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\not-found.tsx\"],\n        metadata: {\n    icon: [(async (props) => (await Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! next-metadata-image-loader?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__ */ \"(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__\"))).default(props))],\n    apple: [],\n    openGraph: [],\n    twitter: [],\n    manifest: undefined\n  }\n      }\n      ]\n      }.children;\nconst pages = [];\n\n\nconst __next_app_require__ = __webpack_require__\nconst __next_app_load_chunk__ = () => Promise.resolve()\nconst originalPathname = \"/not-found\";\nconst __next_app__ = {\n    require: __next_app_require__,\n    loadChunk: __next_app_load_chunk__\n};\n\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_app_page_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,\n        page: \"/not-found\",\n        pathname: \"/not-found\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\",\n        appPaths: []\n    },\n    userland: {\n        loaderTree: tree\n    }\n});\n\n//# sourceMappingURL=app-page.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZub3QtZm91bmQmcGFnZT0lMkZub3QtZm91bmQmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGbm90LWZvdW5kLnRzeCZhcHBEaXI9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQlNUNhcHAmcGFnZUV4dGVuc2lvbnM9dHN4JnBhZ2VFeHRlbnNpb25zPXRzJnBhZ2VFeHRlbnNpb25zPWpzeCZwYWdlRXh0ZW5zaW9ucz1qcyZyb290RGlyPUQlM0ElNUNTdHVkZW50cyU1Q0xvY2tlciU1QyVFQyU5RCVCNCVFQyVBMCU5NSVFQyU4NCU5RCU1Q05leHRqcyU1Q2JvYXJkJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsYUFBYSxzQkFBc0I7QUFDaUU7QUFDckM7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBLGdDQUFnQyx3T0FBdUY7QUFDdkg7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLHlCQUF5Qiw0SUFBOEY7QUFDdkgsb0JBQW9CLGtKQUFpRztBQUNySDtBQUNBLG9DQUFvQyw4ZUFBc1A7QUFDMVI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDdUI7QUFDNkQ7QUFDcEYsNkJBQTZCLG1CQUFtQjtBQUNoRDtBQUNPO0FBQ0E7QUFDUDtBQUNBO0FBQ0E7QUFDdUQ7QUFDdkQ7QUFDTyx3QkFBd0IsOEdBQWtCO0FBQ2pEO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLz80NzNmIl0sInNvdXJjZXNDb250ZW50IjpbIlwiVFVSQk9QQUNLIHsgdHJhbnNpdGlvbjogbmV4dC1zc3IgfVwiO1xuaW1wb3J0IHsgQXBwUGFnZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvYXBwLXBhZ2UvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuLy8gV2UgaW5qZWN0IHRoZSB0cmVlIGFuZCBwYWdlcyBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgdHJlZSA9IHtcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgJycsXG4gICAgICAgIHtcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAnX19ERUZBVUxUX18nLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGRlZmF1bHRQYWdlOiBbKCkgPT4gaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCJuZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvcGFyYWxsZWwtcm91dGUtZGVmYXVsdFwiKSwgXCJuZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvcGFyYWxsZWwtcm91dGUtZGVmYXVsdFwiXSxcbiAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgJ2xheW91dCc6IFsoKSA9PiBpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxsYXlvdXQudHN4XCIpLCBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxsYXlvdXQudHN4XCJdLFxuJ25vdC1mb3VuZCc6IFsoKSA9PiBpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxub3QtZm91bmQudHN4XCIpLCBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxub3QtZm91bmQudHN4XCJdLFxuICAgICAgICBtZXRhZGF0YToge1xuICAgIGljb246IFsoYXN5bmMgKHByb3BzKSA9PiAoYXdhaXQgaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCJuZXh0LW1ldGFkYXRhLWltYWdlLWxvYWRlcj90eXBlPWZhdmljb24mc2VnbWVudD0mYmFzZVBhdGg9JnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMhRDpcXFxcU3R1ZGVudHNcXFxcTG9ja2VyXFxcXOydtOygleyEnVxcXFxOZXh0anNcXFxcYm9hcmRcXFxcYXBwXFxcXGZhdmljb24uaWNvP19fbmV4dF9tZXRhZGF0YV9fXCIpKS5kZWZhdWx0KHByb3BzKSldLFxuICAgIGFwcGxlOiBbXSxcbiAgICBvcGVuR3JhcGg6IFtdLFxuICAgIHR3aXR0ZXI6IFtdLFxuICAgIG1hbmlmZXN0OiB1bmRlZmluZWRcbiAgfVxuICAgICAgfVxuICAgICAgXVxuICAgICAgfS5jaGlsZHJlbjtcbmNvbnN0IHBhZ2VzID0gW107XG5leHBvcnQgeyB0cmVlLCBwYWdlcyB9O1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBHbG9iYWxFcnJvciB9IGZyb20gXCJuZXh0L2Rpc3QvY2xpZW50L2NvbXBvbmVudHMvZXJyb3ItYm91bmRhcnlcIjtcbmNvbnN0IF9fbmV4dF9hcHBfcmVxdWlyZV9fID0gX193ZWJwYWNrX3JlcXVpcmVfX1xuY29uc3QgX19uZXh0X2FwcF9sb2FkX2NodW5rX18gPSAoKSA9PiBQcm9taXNlLnJlc29sdmUoKVxuZXhwb3J0IGNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9ub3QtZm91bmRcIjtcbmV4cG9ydCBjb25zdCBfX25leHRfYXBwX18gPSB7XG4gICAgcmVxdWlyZTogX19uZXh0X2FwcF9yZXF1aXJlX18sXG4gICAgbG9hZENodW5rOiBfX25leHRfYXBwX2xvYWRfY2h1bmtfX1xufTtcbmV4cG9ydCAqIGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2FwcC1yZW5kZXIvZW50cnktYmFzZVwiO1xuLy8gQ3JlYXRlIGFuZCBleHBvcnQgdGhlIHJvdXRlIG1vZHVsZSB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG5leHBvcnQgY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUGFnZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUEFHRSxcbiAgICAgICAgcGFnZTogXCIvbm90LWZvdW5kXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9ub3QtZm91bmRcIixcbiAgICAgICAgLy8gVGhlIGZvbGxvd2luZyBhcmVuJ3QgdXNlZCBpbiBwcm9kdWN0aW9uLlxuICAgICAgICBidW5kbGVQYXRoOiBcIlwiLFxuICAgICAgICBmaWxlbmFtZTogXCJcIixcbiAgICAgICAgYXBwUGF0aHM6IFtdXG4gICAgfSxcbiAgICB1c2VybGFuZDoge1xuICAgICAgICBsb2FkZXJUcmVlOiB0cmVlXG4gICAgfVxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1wYWdlLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fnot-found&page=%2Fnot-found&appPaths=&pagePath=private-next-app-dir%2Fnot-found.tsx&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp%5Cglobals.css&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp%5Csession.tsx&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Clink.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cfont%5Cgoogle%5Ctarget.css%3F%7B%22path%22%3A%22app%5C%5Clayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&server=true!":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp%5Cglobals.css&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp%5Csession.tsx&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Clink.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cfont%5Cgoogle%5Ctarget.css%3F%7B%22path%22%3A%22app%5C%5Clayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&server=true! ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./app/session.tsx */ \"(ssr)/./app/session.tsx\"));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/link.js */ \"(ssr)/./node_modules/next/dist/client/link.js\", 23))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQlNUNhcHAlNUNnbG9iYWxzLmNzcyZtb2R1bGVzPUQlM0ElNUNTdHVkZW50cyU1Q0xvY2tlciU1QyVFQyU5RCVCNCVFQyVBMCU5NSVFQyU4NCU5RCU1Q05leHRqcyU1Q2JvYXJkJTVDYXBwJTVDc2Vzc2lvbi50c3gmbW9kdWxlcz1EJTNBJTVDU3R1ZGVudHMlNUNMb2NrZXIlNUMlRUMlOUQlQjQlRUMlQTAlOTUlRUMlODQlOUQlNUNOZXh0anMlNUNib2FyZCU1Q25vZGVfbW9kdWxlcyU1Q25leHQlNUNkaXN0JTVDY2xpZW50JTVDbGluay5qcyZtb2R1bGVzPUQlM0ElNUNTdHVkZW50cyU1Q0xvY2tlciU1QyVFQyU5RCVCNCVFQyVBMCU5NSVFQyU4NCU5RCU1Q05leHRqcyU1Q2JvYXJkJTVDbm9kZV9tb2R1bGVzJTVDbmV4dCU1Q2ZvbnQlNUNnb29nbGUlNUN0YXJnZXQuY3NzJTNGJTdCJTIycGF0aCUyMiUzQSUyMmFwcCU1QyU1Q2xheW91dC50c3glMjIlMkMlMjJpbXBvcnQlMjIlM0ElMjJJbnRlciUyMiUyQyUyMmFyZ3VtZW50cyUyMiUzQSU1QiU3QiUyMnN1YnNldHMlMjIlM0ElNUIlMjJsYXRpbiUyMiU1RCU3RCU1RCUyQyUyMnZhcmlhYmxlTmFtZSUyMiUzQSUyMmludGVyJTIyJTdEJnNlcnZlcj10cnVlISIsIm1hcHBpbmdzIjoiQUFBQSw4SUFBK0Y7QUFDL0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8/ZWNkNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxzZXNzaW9uLnRzeFwiKTtcbmltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiRDpcXFxcU3R1ZGVudHNcXFxcTG9ja2VyXFxcXOydtOygleyEnVxcXFxOZXh0anNcXFxcYm9hcmRcXFxcbm9kZV9tb2R1bGVzXFxcXG5leHRcXFxcZGlzdFxcXFxjbGllbnRcXFxcbGluay5qc1wiKSJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp%5Cglobals.css&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp%5Csession.tsx&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Clink.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cfont%5Cgoogle%5Ctarget.css%3F%7B%22path%22%3A%22app%5C%5Clayout.tsx%22%2C%22import%22%3A%22Inter%22%2C%22arguments%22%3A%5B%7B%22subsets%22%3A%5B%22latin%22%5D%7D%5D%2C%22variableName%22%3A%22inter%22%7D&server=true!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Capp-router.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cerror-boundary.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Clayout-router.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cnot-found-boundary.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Crender-from-template-context.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cstatic-generation-searchparams-bailout-provider.js&server=true!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Capp-router.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cerror-boundary.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Clayout-router.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cnot-found-boundary.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Crender-from-template-context.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cstatic-generation-searchparams-bailout-provider.js&server=true! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

eval("Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/app-router.js */ \"(ssr)/./node_modules/next/dist/client/components/app-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/error-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/error-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/layout-router.js */ \"(ssr)/./node_modules/next/dist/client/components/layout-router.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/not-found-boundary.js */ \"(ssr)/./node_modules/next/dist/client/components/not-found-boundary.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/render-from-template-context.js */ \"(ssr)/./node_modules/next/dist/client/components/render-from-template-context.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js */ \"(ssr)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js\", 23))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWZsaWdodC1jbGllbnQtZW50cnktbG9hZGVyLmpzP21vZHVsZXM9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQlNUNub2RlX21vZHVsZXMlNUNuZXh0JTVDZGlzdCU1Q2NsaWVudCU1Q2NvbXBvbmVudHMlNUNhcHAtcm91dGVyLmpzJm1vZHVsZXM9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQlNUNub2RlX21vZHVsZXMlNUNuZXh0JTVDZGlzdCU1Q2NsaWVudCU1Q2NvbXBvbmVudHMlNUNlcnJvci1ib3VuZGFyeS5qcyZtb2R1bGVzPUQlM0ElNUNTdHVkZW50cyU1Q0xvY2tlciU1QyVFQyU5RCVCNCVFQyVBMCU5NSVFQyU4NCU5RCU1Q05leHRqcyU1Q2JvYXJkJTVDbm9kZV9tb2R1bGVzJTVDbmV4dCU1Q2Rpc3QlNUNjbGllbnQlNUNjb21wb25lbnRzJTVDbGF5b3V0LXJvdXRlci5qcyZtb2R1bGVzPUQlM0ElNUNTdHVkZW50cyU1Q0xvY2tlciU1QyVFQyU5RCVCNCVFQyVBMCU5NSVFQyU4NCU5RCU1Q05leHRqcyU1Q2JvYXJkJTVDbm9kZV9tb2R1bGVzJTVDbmV4dCU1Q2Rpc3QlNUNjbGllbnQlNUNjb21wb25lbnRzJTVDbm90LWZvdW5kLWJvdW5kYXJ5LmpzJm1vZHVsZXM9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQlNUNub2RlX21vZHVsZXMlNUNuZXh0JTVDZGlzdCU1Q2NsaWVudCU1Q2NvbXBvbmVudHMlNUNyZW5kZXItZnJvbS10ZW1wbGF0ZS1jb250ZXh0LmpzJm1vZHVsZXM9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQlNUNub2RlX21vZHVsZXMlNUNuZXh0JTVDZGlzdCU1Q2NsaWVudCU1Q2NvbXBvbmVudHMlNUNzdGF0aWMtZ2VuZXJhdGlvbi1zZWFyY2hwYXJhbXMtYmFpbG91dC1wcm92aWRlci5qcyZzZXJ2ZXI9dHJ1ZSEiLCJtYXBwaW5ncyI6IkFBQUEsa09BQTBJO0FBQzFJLDBPQUE4STtBQUM5SSx3T0FBNkk7QUFDN0ksa1BBQWtKO0FBQ2xKLHNRQUE0SjtBQUM1SiIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLz8zZWRkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCgvKiB3ZWJwYWNrTW9kZTogXCJlYWdlclwiICovIFwiRDpcXFxcU3R1ZGVudHNcXFxcTG9ja2VyXFxcXOydtOygleyEnVxcXFxOZXh0anNcXFxcYm9hcmRcXFxcbm9kZV9tb2R1bGVzXFxcXG5leHRcXFxcZGlzdFxcXFxjbGllbnRcXFxcY29tcG9uZW50c1xcXFxhcHAtcm91dGVyLmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCJEOlxcXFxTdHVkZW50c1xcXFxMb2NrZXJcXFxc7J207KCV7ISdXFxcXE5leHRqc1xcXFxib2FyZFxcXFxub2RlX21vZHVsZXNcXFxcbmV4dFxcXFxkaXN0XFxcXGNsaWVudFxcXFxjb21wb25lbnRzXFxcXGVycm9yLWJvdW5kYXJ5LmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCJEOlxcXFxTdHVkZW50c1xcXFxMb2NrZXJcXFxc7J207KCV7ISdXFxcXE5leHRqc1xcXFxib2FyZFxcXFxub2RlX21vZHVsZXNcXFxcbmV4dFxcXFxkaXN0XFxcXGNsaWVudFxcXFxjb21wb25lbnRzXFxcXGxheW91dC1yb3V0ZXIuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXG5vZGVfbW9kdWxlc1xcXFxuZXh0XFxcXGRpc3RcXFxcY2xpZW50XFxcXGNvbXBvbmVudHNcXFxcbm90LWZvdW5kLWJvdW5kYXJ5LmpzXCIpO1xuaW1wb3J0KC8qIHdlYnBhY2tNb2RlOiBcImVhZ2VyXCIgKi8gXCJEOlxcXFxTdHVkZW50c1xcXFxMb2NrZXJcXFxc7J207KCV7ISdXFxcXE5leHRqc1xcXFxib2FyZFxcXFxub2RlX21vZHVsZXNcXFxcbmV4dFxcXFxkaXN0XFxcXGNsaWVudFxcXFxjb21wb25lbnRzXFxcXHJlbmRlci1mcm9tLXRlbXBsYXRlLWNvbnRleHQuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXG5vZGVfbW9kdWxlc1xcXFxuZXh0XFxcXGRpc3RcXFxcY2xpZW50XFxcXGNvbXBvbmVudHNcXFxcc3RhdGljLWdlbmVyYXRpb24tc2VhcmNocGFyYW1zLWJhaWxvdXQtcHJvdmlkZXIuanNcIikiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Capp-router.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cerror-boundary.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Clayout-router.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cnot-found-boundary.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Crender-from-template-context.js&modules=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Ccomponents%5Cstatic-generation-searchparams-bailout-provider.js&server=true!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./app/session.tsx":
/*!*************************!*\
  !*** ./app/session.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ AuthSession)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(ssr)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/react */ \"(ssr)/./node_modules/next-auth/react/index.js\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);\n/* __next_internal_client_entry_do_not_use__ default auto */ \n\nfunction AuthSession({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_1__.SessionProvider, {\n        children: children\n    }, void 0, false, {\n        fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\session.tsx\",\n        lineNumber: 10,\n        columnNumber: 12\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9hcHAvc2Vzc2lvbi50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBRWlEO0FBTWxDLFNBQVNDLFlBQVksRUFBQ0MsUUFBUSxFQUFTO0lBQ2xELHFCQUFPLDhEQUFDRiw0REFBZUE7a0JBQUVFOzs7Ozs7QUFDN0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9zZXNzaW9uLnRzeD8wM2YwIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2UgY2xpZW50J1xyXG5cclxuaW1wb3J0IHsgU2Vzc2lvblByb3ZpZGVyIH0gZnJvbSBcIm5leHQtYXV0aC9yZWFjdFwiXHJcblxyXG5pbnRlcmZhY2UgUHJvcHN7XHJcbiAgICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGhTZXNzaW9uKHtjaGlsZHJlbn0gOiBQcm9wcyl7XHJcbiAgICByZXR1cm4gPFNlc3Npb25Qcm92aWRlcj57Y2hpbGRyZW59PC9TZXNzaW9uUHJvdmlkZXI+XHJcbn0iXSwibmFtZXMiOlsiU2Vzc2lvblByb3ZpZGVyIiwiQXV0aFNlc3Npb24iLCJjaGlsZHJlbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./app/session.tsx\n");

/***/ }),

/***/ "(rsc)/./app/globals.css":
/*!*************************!*\
  !*** ./app/globals.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (\"d88dc6b14989\");\nif (false) {}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvZ2xvYmFscy5jc3MiLCJtYXBwaW5ncyI6Ijs7OztBQUFBLGlFQUFlLGNBQWM7QUFDN0IsSUFBSSxLQUFVLEVBQUUsRUFBdUIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9nbG9iYWxzLmNzcz8xYTMwIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IFwiZDg4ZGM2YjE0OTg5XCJcbmlmIChtb2R1bGUuaG90KSB7IG1vZHVsZS5ob3QuYWNjZXB0KCkgfVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./app/globals.css\n");

/***/ }),

/***/ "(rsc)/./app/api/auth/[...nextauth]/route.ts":
/*!*********************************************!*\
  !*** ./app/api/auth/[...nextauth]/route.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ handler),\n/* harmony export */   POST: () => (/* binding */ handler),\n/* harmony export */   authOptions: () => (/* binding */ authOptions)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"(rsc)/./node_modules/next-auth/index.js\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/github */ \"(rsc)/./node_modules/next-auth/providers/github.js\");\n/* harmony import */ var next_auth_providers_kakao__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth/providers/kakao */ \"(rsc)/./node_modules/next-auth/providers/kakao.js\");\n/* harmony import */ var next_auth_providers_naver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-auth/providers/naver */ \"(rsc)/./node_modules/next-auth/providers/naver.js\");\n/* harmony import */ var next_auth_providers_google__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next-auth/providers/google */ \"(rsc)/./node_modules/next-auth/providers/google.js\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next-auth/providers/credentials */ \"(rsc)/./node_modules/next-auth/providers/credentials.js\");\n/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/db */ \"(rsc)/./db.js\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_7__);\n\n\n\n\n\n\n\n\nconst authOptions = {\n    providers: [\n        (0,next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__[\"default\"])({\n            clientId: `${process.env.GITHUB_ID}`,\n            clientSecret: `${process.env.GITHUB_PW}` //env로 변경해서 써주기\n        }),\n        (0,next_auth_providers_kakao__WEBPACK_IMPORTED_MODULE_2__[\"default\"])({\n            clientId: `${process.env.KAKAO_ID}`,\n            clientSecret: `${process.env.KAKAO_PW}` // 비밀번호는 카카오로그인 -> 보안 ->코드생성 후 -> 코드 복사해서 붙이기\n        }),\n        (0,next_auth_providers_naver__WEBPACK_IMPORTED_MODULE_3__[\"default\"])({\n            clientId: `${process.env.NAVER_ID}`,\n            clientSecret: `${process.env.NAVER_PW}` // 비밀번호는 카카오로그인 -> 보안 ->코드생성 후 -> 코드 복사해서 붙이기\n        }),\n        (0,next_auth_providers_google__WEBPACK_IMPORTED_MODULE_4__[\"default\"])({\n            clientId: `${process.env.GOOGLE_ID}`,\n            clientSecret: `${process.env.GOOGLE_PW}`\n        }),\n        (0,next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_5__[\"default\"])({\n            name: \"Credentials\",\n            credentials: {\n                email: {\n                    label: \"email\",\n                    type: \"text\",\n                    placeholder: \"email을 입력하세요\"\n                },\n                password: {\n                    label: \"Password\",\n                    type: \"password\"\n                }\n            },\n            async authorize (credentials) {\n                try {\n                    const [results] = await _db__WEBPACK_IMPORTED_MODULE_6__[\"default\"].query(\"select * from board.member where email = ?\", [\n                        credentials?.email\n                    ]);\n                    console.log(results[0].email);\n                    const userResult = results[0];\n                    if (!credentials || !credentials.email || !credentials.password) {\n                        return null;\n                    }\n                    if (!results[0].email || !userResult.password) {\n                        console.log(\"해당 사용자가 없습니다.\");\n                        return null;\n                    }\n                    const pwCheck = await bcrypt__WEBPACK_IMPORTED_MODULE_7___default().compare(credentials.password, results[0].password);\n                    if (!pwCheck) {\n                        console.log(\"비밀번호 에러\");\n                        return null;\n                    }\n                    const user = {\n                        id: userResult.id,\n                        name: userResult.name,\n                        email: userResult.email,\n                        level: userResult.level\n                    };\n                    return user;\n                } catch (error) {\n                    return null;\n                }\n            }\n        })\n    ],\n    // pages: {\n    //     signIn: '/login'\n    // },\n    // jwt 만료일 설정\n    session: {\n        strategy: \"jwt\",\n        maxAge: 24 * 60 * 60\n    },\n    // jwt 만들 때 실행 되는 코드 ( 토큰 발급 )\n    callbacks: {\n        jwt: async ({ token, user })=>{\n            if (user) {\n                token.user = {\n                    name: user.name,\n                    email: user.email,\n                    level: user.level\n                };\n            }\n            return token;\n        },\n        session: async ({ session, token })=>{\n            session.user = token.user;\n            return session;\n        }\n    },\n    secret: `${process.env.SECRET}`\n};\nconst handler = next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions);\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQWlDO0FBQ2U7QUFDTztBQUNBO0FBQ0U7QUFDUztBQUM1QztBQUNNO0FBZ0JyQixNQUFNUSxjQUFtQjtJQUM1QkMsV0FBWTtRQUNSUixzRUFBTUEsQ0FBQztZQUNIUyxVQUFTLENBQUMsRUFBRUMsUUFBUUMsR0FBRyxDQUFDQyxTQUFTLENBQUMsQ0FBQztZQUNuQ0MsY0FBYyxDQUFDLEVBQUVILFFBQVFDLEdBQUcsQ0FBQ0csU0FBUyxDQUFDLENBQUMsQ0FBUyxlQUFlO1FBQ3BFO1FBQ0FiLHFFQUFhQSxDQUFDO1lBQ1ZRLFVBQVMsQ0FBQyxFQUFFQyxRQUFRQyxHQUFHLENBQUNJLFFBQVEsQ0FBQyxDQUFDO1lBQ2xDRixjQUFjLENBQUMsRUFBRUgsUUFBUUMsR0FBRyxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUEwQiw2Q0FBNkM7UUFDbEg7UUFDQWQscUVBQWFBLENBQUM7WUFDVk8sVUFBUyxDQUFDLEVBQUVDLFFBQVFDLEdBQUcsQ0FBQ00sUUFBUSxDQUFDLENBQUM7WUFDbENKLGNBQWMsQ0FBQyxFQUFFSCxRQUFRQyxHQUFHLENBQUNPLFFBQVEsQ0FBQyxDQUFDLENBQW9DLDZDQUE2QztRQUM1SDtRQUNBZixzRUFBY0EsQ0FBQztZQUNYTSxVQUFTLENBQUMsRUFBRUMsUUFBUUMsR0FBRyxDQUFDUSxTQUFTLENBQUMsQ0FBQztZQUNuQ04sY0FBYSxDQUFDLEVBQUVILFFBQVFDLEdBQUcsQ0FBQ1MsU0FBUyxDQUFDLENBQUM7UUFDM0M7UUFDQWhCLDJFQUFtQkEsQ0FBQztZQUVoQmlCLE1BQU07WUFDTkMsYUFBYTtnQkFDWEMsT0FBTztvQkFBRUMsT0FBTztvQkFBU0MsTUFBTTtvQkFBUUMsYUFBYTtnQkFBZTtnQkFDbkVDLFVBQVU7b0JBQUVILE9BQU87b0JBQVlDLE1BQU07Z0JBQVc7WUFDbEQ7WUFDQSxNQUFNRyxXQUFVTixXQUFXO2dCQUV2QixJQUFHO29CQUNDLE1BQU0sQ0FBQ08sUUFBUSxHQUFHLE1BQU14QiwyQ0FBRUEsQ0FBQ3lCLEtBQUssQ0FBa0IsOENBQThDO3dCQUFDUixhQUFhQztxQkFBTTtvQkFDcEhRLFFBQVFDLEdBQUcsQ0FBQ0gsT0FBTyxDQUFDLEVBQUUsQ0FBQ04sS0FBSztvQkFDNUIsTUFBTVUsYUFBYUosT0FBTyxDQUFDLEVBQUU7b0JBQzdCLElBQUcsQ0FBQ1AsZUFBZSxDQUFDQSxZQUFZQyxLQUFLLElBQUksQ0FBQ0QsWUFBWUssUUFBUSxFQUFDO3dCQUMzRCxPQUFPO29CQUNYO29CQUNBLElBQUcsQ0FBQ0UsT0FBTyxDQUFDLEVBQUUsQ0FBQ04sS0FBSyxJQUFJLENBQUNVLFdBQVdOLFFBQVEsRUFBQzt3QkFDekNJLFFBQVFDLEdBQUcsQ0FBQzt3QkFDWixPQUFPO29CQUNYO29CQUNBLE1BQU1FLFVBQVUsTUFBTTVCLHFEQUFjLENBQUNnQixZQUFZSyxRQUFRLEVBQUdFLE9BQU8sQ0FBQyxFQUFFLENBQUNGLFFBQVE7b0JBRS9FLElBQUcsQ0FBQ08sU0FBUTt3QkFDUkgsUUFBUUMsR0FBRyxDQUFDO3dCQUNaLE9BQU87b0JBQ1g7b0JBQ0EsTUFBTUksT0FBWTt3QkFDZEMsSUFBS0osV0FBV0ksRUFBRTt3QkFDbEJoQixNQUFNWSxXQUFXWixJQUFJO3dCQUNyQkUsT0FBT1UsV0FBV1YsS0FBSzt3QkFDdkJlLE9BQU9MLFdBQVdLLEtBQUs7b0JBQzNCO29CQUNBLE9BQU9GO2dCQUNYLEVBQUMsT0FBTUcsT0FBTTtvQkFDVCxPQUFPO2dCQUNYO1lBQ0o7UUFBQztLQUNSO0lBQ0QsV0FBVztJQUNYLHVCQUF1QjtJQUN2QixLQUFLO0lBRUwsYUFBYTtJQUNiQyxTQUFVO1FBQ05DLFVBQVc7UUFDWEMsUUFBUSxLQUFLLEtBQUs7SUFDdEI7SUFDQSw4QkFBOEI7SUFDOUJDLFdBQVk7UUFDUkMsS0FBSyxPQUFPLEVBQUNDLEtBQUssRUFBRVQsSUFBSSxFQUE0QjtZQUNoRCxJQUFHQSxNQUFLO2dCQUNKUyxNQUFNVCxJQUFJLEdBQUU7b0JBQ1JmLE1BQU1lLEtBQUtmLElBQUk7b0JBQ2ZFLE9BQU9hLEtBQUtiLEtBQUs7b0JBQ2pCZSxPQUFRRixLQUFLRSxLQUFLO2dCQUN0QjtZQUNKO1lBQ0EsT0FBT087UUFDWDtRQUNBTCxTQUFVLE9BQU8sRUFBQ0EsT0FBTyxFQUFDSyxLQUFLLEVBQXdDO1lBQ25FTCxRQUFRSixJQUFJLEdBQUdTLE1BQU1ULElBQUk7WUFDekIsT0FBT0k7UUFDWDtJQUNKO0lBQ0FNLFFBQVEsQ0FBQyxFQUFFcEMsUUFBUUMsR0FBRyxDQUFDb0MsTUFBTSxDQUFDLENBQUM7QUFFbkMsRUFBRTtBQUdGLE1BQU1DLFVBQVVqRCxnREFBUUEsQ0FBQ1E7QUFDZ0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlLnRzP2M4YTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5leHRBdXRoIGZyb20gXCJuZXh0LWF1dGhcIjtcclxuaW1wb3J0IEdpdGh1YiBmcm9tIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9naXRodWJcIjtcclxuaW1wb3J0IEtha2FvUHJvdmlkZXIgZnJvbSAgXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2tha2FvXCI7XHJcbmltcG9ydCBOYXZlclByb3ZpZGVyIGZyb20gIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9uYXZlclwiO1xyXG5pbXBvcnQgR29vZ2xlUHJvdmlkZXIgZnJvbSAgXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2dvb2dsZVwiO1xyXG5pbXBvcnQgQ3JlZGVudGlhbHNQcm92aWRlciBmcm9tIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9jcmVkZW50aWFsc1wiO1xyXG5pbXBvcnQgZGIgZnJvbSAnQC9kYic7XHJcbmltcG9ydCBiY3J5cHQgZnJvbSAnYmNyeXB0JztcclxuaW1wb3J0IHsgUm93RGF0YVBhY2tldCB9IGZyb20gXCJteXNxbDJcIjtcclxuaW1wb3J0IHsgSldUIH0gZnJvbSBcIm5leHQtYXV0aC9qd3RcIjtcclxuaW1wb3J0IHsgU2Vzc2lvbiB9IGZyb20gXCJuZXh0LWF1dGhcIjtcclxuXHJcbmludGVyZmFjZSBVc2Vye1xyXG4gICAgaWQ6IHN0cmluZztcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIGVtYWlsOiBzdHJpbmc7XHJcbiAgICBsZXZlbDogc3RyaW5nXHJcbn1cclxuXHJcbmludGVyZmFjZSBDdXN0b21TZXNzaW9uIGV4dGVuZHMgU2Vzc2lvbntcclxuICAgIHVzZXI/OiBVc2VyXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBhdXRoT3B0aW9ucyA6YW55ID0ge1xyXG4gICAgcHJvdmlkZXJzIDogW1xyXG4gICAgICAgIEdpdGh1Yih7XHJcbiAgICAgICAgICAgIGNsaWVudElkOmAke3Byb2Nlc3MuZW52LkdJVEhVQl9JRH1gLFxyXG4gICAgICAgICAgICBjbGllbnRTZWNyZXQ6IGAke3Byb2Nlc3MuZW52LkdJVEhVQl9QV31gICAgICAgICAgLy9lbnbroZwg67OA6rK97ZW07IScIOyNqOyjvOq4sFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIEtha2FvUHJvdmlkZXIoe1xyXG4gICAgICAgICAgICBjbGllbnRJZDpgJHtwcm9jZXNzLmVudi5LQUtBT19JRH1gLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8v7Lm07Lm07Jik7YahIOqwnOuwnOyekCDslbEg7ISk7KCVLT4g7JWxIO2CpCAtPiBSZXN0IEFQSSBLRVnsnoXroKVcclxuICAgICAgICAgICAgY2xpZW50U2VjcmV0OiBgJHtwcm9jZXNzLmVudi5LQUtBT19QV31gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDruYTrsIDrsojtmLjripQg7Lm07Lm07Jik66Gc6re47J24IC0+IOuztOyViCAtPuy9lOuTnOyDneyEsSDtm4QgLT4g7L2U65OcIOuzteyCrO2VtOyEnCDrtpnsnbTquLBcclxuICAgICAgICB9KSxcclxuICAgICAgICBOYXZlclByb3ZpZGVyKHtcclxuICAgICAgICAgICAgY2xpZW50SWQ6YCR7cHJvY2Vzcy5lbnYuTkFWRVJfSUR9YCwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+y5tOy5tOyYpO2GoSDqsJzrsJzsnpAg7JWxIOyEpOyglS0+IOyVsSDtgqQgLT4gUmVzdCBBUEkgS0VZ7J6F66ClXHJcbiAgICAgICAgICAgIGNsaWVudFNlY3JldDogYCR7cHJvY2Vzcy5lbnYuTkFWRVJfUFd9YCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIOu5hOuwgOuyiO2YuOuKlCDsubTsubTsmKTroZzqt7jsnbggLT4g67O07JWIIC0+7L2U65Oc7IOd7ISxIO2bhCAtPiDsvZTrk5wg67O17IKs7ZW07IScIOu2meydtOq4sFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIEdvb2dsZVByb3ZpZGVyKHtcclxuICAgICAgICAgICAgY2xpZW50SWQ6YCR7cHJvY2Vzcy5lbnYuR09PR0xFX0lEfWAsICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgY2xpZW50U2VjcmV0OmAke3Byb2Nlc3MuZW52LkdPT0dMRV9QV31gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIENyZWRlbnRpYWxzUHJvdmlkZXIoe1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAgIG5hbWU6IFwiQ3JlZGVudGlhbHNcIixcclxuICAgICAgICAgICAgY3JlZGVudGlhbHM6IHtcclxuICAgICAgICAgICAgICBlbWFpbDogeyBsYWJlbDogXCJlbWFpbFwiLCB0eXBlOiBcInRleHRcIiwgcGxhY2Vob2xkZXI6IFwiZW1haWzsnYQg7J6F66Cl7ZWY7IS47JqUXCIgfSxcclxuICAgICAgICAgICAgICBwYXNzd29yZDogeyBsYWJlbDogXCJQYXNzd29yZFwiLCB0eXBlOiBcInBhc3N3b3JkXCIgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBhdXRob3JpemUoY3JlZGVudGlhbHMpIDogUHJvbWlzZTxVc2VyIHwgbnVsbD57XHJcblxyXG4gICAgICAgICAgICAgICAgdHJ5e1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IFtyZXN1bHRzXSA9IGF3YWl0IGRiLnF1ZXJ5PFJvd0RhdGFQYWNrZXRbXT4oJ3NlbGVjdCAqIGZyb20gYm9hcmQubWVtYmVyIHdoZXJlIGVtYWlsID0gPycsIFtjcmVkZW50aWFscz8uZW1haWxdKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHRzWzBdLmVtYWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJSZXN1bHQgPSByZXN1bHRzWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgaWYoIWNyZWRlbnRpYWxzIHx8ICFjcmVkZW50aWFscy5lbWFpbCB8fCAhY3JlZGVudGlhbHMucGFzc3dvcmQpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZighcmVzdWx0c1swXS5lbWFpbCB8fCAhdXNlclJlc3VsdC5wYXNzd29yZCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi7ZW064u5IOyCrOyaqeyekOqwgCDsl4bsirXri4jri6QuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBwd0NoZWNrID0gYXdhaXQgYmNyeXB0LmNvbXBhcmUoY3JlZGVudGlhbHMucGFzc3dvcmQgLCByZXN1bHRzWzBdLnBhc3N3b3JkKTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBpZighcHdDaGVjayl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi67mE67CA67KI7Zi4IOyXkOufrFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VyOlVzZXIgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkIDogdXNlclJlc3VsdC5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogdXNlclJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdXNlclJlc3VsdC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV2ZWw6IHVzZXJSZXN1bHQubGV2ZWxcclxuICAgICAgICAgICAgICAgICAgICB9ICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB1c2VyO1xyXG4gICAgICAgICAgICAgICAgfWNhdGNoKGVycm9yKXtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9fSlcclxuICAgIF0sXHJcbiAgICAvLyBwYWdlczoge1xyXG4gICAgLy8gICAgIHNpZ25JbjogJy9sb2dpbidcclxuICAgIC8vIH0sXHJcblxyXG4gICAgLy8gand0IOunjOujjOydvCDshKTsoJVcclxuICAgIHNlc3Npb24gOiB7XHJcbiAgICAgICAgc3RyYXRlZ3kgOiAnand0JyxcclxuICAgICAgICBtYXhBZ2U6IDI0ICogNjAgKiA2MFxyXG4gICAgfSxcclxuICAgIC8vIGp3dCDrp4zrk6Qg65WMIOyLpO2WiSDrkJjripQg7L2U65OcICgg7Yag7YGwIOuwnOq4iSApXHJcbiAgICBjYWxsYmFja3MgOiB7XHJcbiAgICAgICAgand0OiBhc3luYyAoe3Rva2VuLCB1c2VyfSA6IHt0b2tlbjpKV1QgLCB1c2VyPzpVc2VyfSk9PntcclxuICAgICAgICAgICAgaWYodXNlcil7XHJcbiAgICAgICAgICAgICAgICB0b2tlbi51c2VyID17XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICAgIGxldmVsIDogdXNlci5sZXZlbFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdG9rZW5cclxuICAgICAgICB9LFxyXG4gICAgICAgIHNlc3Npb24gOiBhc3luYyAoe3Nlc3Npb24sdG9rZW59IDoge3Nlc3Npb246IEN1c3RvbVNlc3Npb24sIHRva2VuOiBKV1R9KT0+e1xyXG4gICAgICAgICAgICBzZXNzaW9uLnVzZXIgPSB0b2tlbi51c2VyIGFzIFVzZXI7XHJcbiAgICAgICAgICAgIHJldHVybiBzZXNzaW9uXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHNlY3JldDogYCR7cHJvY2Vzcy5lbnYuU0VDUkVUfWAsIC8vand0IOyDneyEseyLnCDtlYTsmpTtlZwg67mE67CA67KI7Zi4XHJcbiAgICBcclxufTtcclxuXHJcblxyXG5jb25zdCBoYW5kbGVyID0gbmV4dEF1dGgoYXV0aE9wdGlvbnMpO1xyXG5leHBvcnQgeyBoYW5kbGVyIGFzIEdFVCwgaGFuZGxlciBhcyBQT1NUfVxyXG5cclxuXHJcbiJdLCJuYW1lcyI6WyJuZXh0QXV0aCIsIkdpdGh1YiIsIktha2FvUHJvdmlkZXIiLCJOYXZlclByb3ZpZGVyIiwiR29vZ2xlUHJvdmlkZXIiLCJDcmVkZW50aWFsc1Byb3ZpZGVyIiwiZGIiLCJiY3J5cHQiLCJhdXRoT3B0aW9ucyIsInByb3ZpZGVycyIsImNsaWVudElkIiwicHJvY2VzcyIsImVudiIsIkdJVEhVQl9JRCIsImNsaWVudFNlY3JldCIsIkdJVEhVQl9QVyIsIktBS0FPX0lEIiwiS0FLQU9fUFciLCJOQVZFUl9JRCIsIk5BVkVSX1BXIiwiR09PR0xFX0lEIiwiR09PR0xFX1BXIiwibmFtZSIsImNyZWRlbnRpYWxzIiwiZW1haWwiLCJsYWJlbCIsInR5cGUiLCJwbGFjZWhvbGRlciIsInBhc3N3b3JkIiwiYXV0aG9yaXplIiwicmVzdWx0cyIsInF1ZXJ5IiwiY29uc29sZSIsImxvZyIsInVzZXJSZXN1bHQiLCJwd0NoZWNrIiwiY29tcGFyZSIsInVzZXIiLCJpZCIsImxldmVsIiwiZXJyb3IiLCJzZXNzaW9uIiwic3RyYXRlZ3kiLCJtYXhBZ2UiLCJjYWxsYmFja3MiLCJqd3QiLCJ0b2tlbiIsInNlY3JldCIsIlNFQ1JFVCIsImhhbmRsZXIiLCJHRVQiLCJQT1NUIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/auth/[...nextauth]/route.ts\n");

/***/ }),

/***/ "(rsc)/./app/components/login.tsx":
/*!**********************************!*\
  !*** ./app/components/login.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Login)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"(rsc)/./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth */ \"(rsc)/./node_modules/next-auth/index.js\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _api_auth_nextauth_route__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api/auth/[...nextauth]/route */ \"(rsc)/./app/api/auth/[...nextauth]/route.ts\");\n\n\n// import { useCustomSession } from \"../sessions\";\n\n\nasync function Login() {\n    let session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_2__.getServerSession)(_api_auth_nextauth_route__WEBPACK_IMPORTED_MODULE_3__.authOptions);\n    // const {data : session, status} = useCustomSession()\n    const redirectTo = ()=>{\n        sessionStorage.setItem(\"preUrl\", window.location.href);\n        window.location.href = \"/login\";\n    };\n    {\n        session && session.user ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                    children: [\n                        session && session.user?.name,\n                        \"님 반갑습니다.\"\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                    lineNumber: 33,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                    href: \"/logout\",\n                    children: \"로그아웃\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                    lineNumber: 34,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                    href: \"/register\",\n                    children: \"회원가입\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                    lineNumber: 39,\n                    columnNumber: 10\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    children: \"로그인\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                    lineNumber: 40,\n                    columnNumber: 10\n                }, this)\n            ]\n        }, void 0, true);\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"max-w-7xl flex justify-between mt-10 mx-auto border-b p-[2%]\",\n            children: [\n                session && session.user.level === 10 ? \"관리자\" : session && session.user !== null && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"mx-auto\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            className: \"font-bold text-4xl \",\n                            children: 'OO님의 등급은 \"일반 회원\" 입니다.'\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                            lineNumber: 50,\n                            columnNumber: 69\n                        }, this),\n                        \" \"\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                    lineNumber: 50,\n                    columnNumber: 44\n                }, this),\n                session && session.user ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    className: \"bg-orange-400 p-6 text-white rounded-md\",\n                    children: \"로그아웃\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                    lineNumber: 53,\n                    columnNumber: 36\n                }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                            href: \"/login\",\n                            children: \"통합로그인\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                            lineNumber: 57,\n                            columnNumber: 10\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                            href: \"/register\",\n                            children: [\n                                \" \",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                                    children: \"회원가입\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                                    lineNumber: 58,\n                                    columnNumber: 34\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                            lineNumber: 58,\n                            columnNumber: 10\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"flex max-w-7xl justify-around\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n                            lineNumber: 59,\n                            columnNumber: 10\n                        }, this)\n                    ]\n                }, void 0, true)\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\components\\\\login.tsx\",\n            lineNumber: 46,\n            columnNumber: 9\n        }, this)\n    }, void 0, false);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvY29tcG9uZW50cy9sb2dpbi50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBVzZCO0FBQzdCLGtEQUFrRDtBQUNMO0FBQ2lCO0FBSS9DLGVBQWVHO0lBRTFCLElBQUlDLFVBQVUsTUFBTUgsMkRBQWdCQSxDQUFDQyxpRUFBV0E7SUFFaEQsc0RBQXNEO0lBQ3RELE1BQU1HLGFBQWE7UUFDZkMsZUFBZUMsT0FBTyxDQUFDLFVBQVVDLE9BQU9DLFFBQVEsQ0FBQ0MsSUFBSTtRQUNyREYsT0FBT0MsUUFBUSxDQUFDQyxJQUFJLEdBQUU7SUFDMUI7SUFFSjtRQUNJTixXQUFXQSxRQUFRTyxJQUFJLGlCQUV2Qjs7OEJBQ0ksOERBQUNDOzt3QkFBR1IsV0FBV0EsUUFBUU8sSUFBSSxFQUFFRTt3QkFBSzs7Ozs7Ozs4QkFDbEMsOERBQUNiLGtEQUFJQTtvQkFBQ1UsTUFBSzs4QkFBVTs7Ozs7Ozt5Q0FJckI7OzhCQUNDLDhEQUFDVixrREFBSUE7b0JBQUNVLE1BQUs7OEJBQVk7Ozs7Ozs4QkFDdkIsOERBQUNJOzhCQUFPOzs7Ozs7OztJQUVqQjtJQUVJLHFCQUNJO2tCQUNBLDRFQUFDQztZQUFJQyxXQUFVOztnQkFFZlosV0FBV0EsUUFBUU8sSUFBSSxDQUFDTSxLQUFLLEtBQUssS0FBSyxRQUV2Q2IsV0FBV0EsUUFBUU8sSUFBSSxLQUFJLHNCQUFRLDhEQUFDSTtvQkFBSUMsV0FBVTs7c0NBQVUsOERBQUNFOzRCQUFLRixXQUFVO3NDQUFzQjs7Ozs7O3dCQUE0Qjs7Ozs7OztnQkFHN0haLFdBQVdBLFFBQVFPLElBQUksaUJBQUcsOERBQUNHO29CQUFPRSxXQUFVOzhCQUEwQzs7Ozs7eUNBR3ZGOztzQ0FDQyw4REFBQ2hCLGtEQUFJQTs0QkFBQ1UsTUFBSztzQ0FBUzs7Ozs7O3NDQUNwQiw4REFBQ1Ysa0RBQUlBOzRCQUFDVSxNQUFLOztnQ0FBWTs4Q0FBQyw4REFBQ0U7OENBQUU7Ozs7Ozs7Ozs7OztzQ0FDM0IsOERBQUNHOzRCQUFJQyxXQUFVOzs7Ozs7Ozs7Ozs7Ozs7QUFjeEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9jb21wb25lbnRzL2xvZ2luLnRzeD9jNTIxIl0sInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSB1c2VySW5mbyB7XHJcbiAgICB1c2VyOiB7XHJcbiAgICAgIG5hbWU6IHN0cmluZztcclxuICAgICAgZW1haWw/OiBzdHJpbmc7XHJcbiAgICAgIGltYWdlPzogc3RyaW5nO1xyXG4gICAgICBsZXZlbD86IG51bWJlcjtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuaW1wb3J0IHsgc2lnbkluLCBzaWduT3V0IH0gZnJvbSBcIm5leHQtYXV0aC9yZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbi8vIGltcG9ydCB7IHVzZUN1c3RvbVNlc3Npb24gfSBmcm9tIFwiLi4vc2Vzc2lvbnNcIjtcclxuaW1wb3J0IHsgZ2V0U2VydmVyU2Vzc2lvbiB9IGZyb20gJ25leHQtYXV0aCc7XHJcbmltcG9ydCB7IGF1dGhPcHRpb25zIH0gZnJvbSBcIi4uL2FwaS9hdXRoL1suLi5uZXh0YXV0aF0vcm91dGVcIjtcclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gTG9naW4oKXtcclxuXHJcbiAgICBsZXQgc2Vzc2lvbiA9IGF3YWl0IGdldFNlcnZlclNlc3Npb24oYXV0aE9wdGlvbnMpIGFzIHVzZXJJbmZvXHJcbiAgICBcclxuICAgIC8vIGNvbnN0IHtkYXRhIDogc2Vzc2lvbiwgc3RhdHVzfSA9IHVzZUN1c3RvbVNlc3Npb24oKVxyXG4gICAgY29uc3QgcmVkaXJlY3RUbyA9ICgpID0+e1xyXG4gICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ3ByZVVybCcsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKVxyXG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmPSBcIi9sb2dpblwiXHJcbiAgICB9XHJcblxyXG57XHJcbiAgICBzZXNzaW9uICYmIHNlc3Npb24udXNlciBcclxuICAgID8gXHJcbiAgICA8PlxyXG4gICAgICAgIDxwPntzZXNzaW9uICYmIHNlc3Npb24udXNlcj8ubmFtZX3ri5gg67CY6rCR7Iq164uI64ukLjwvcD5cclxuICAgICAgICA8TGluayBocmVmPVwiL2xvZ291dFwiPuuhnOq3uOyVhOybgzwvTGluaz5cclxuICAgIDwvPlxyXG4gICAgXHJcbjpcclxuICAgICAgICA8PlxyXG4gICAgICAgICA8TGluayBocmVmPVwiL3JlZ2lzdGVyXCI+7ZqM7JuQ6rCA7J6FPC9MaW5rPlxyXG4gICAgICAgICA8YnV0dG9uPuuhnOq3uOyduDwvYnV0dG9uPlxyXG4gICAgICAgIDwvPlxyXG59XHJcblxyXG4gICAgcmV0dXJuKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgZmxleCBqdXN0aWZ5LWJldHdlZW4gbXQtMTAgbXgtYXV0byBib3JkZXItYiBwLVsyJV1cIj5cclxuICAgICAgIHtcclxuICAgICAgICBzZXNzaW9uICYmIHNlc3Npb24udXNlci5sZXZlbCA9PT0gMTAgPyAn6rSA66as7J6QJyBcclxuICAgICAgICA6XHJcbiAgICAgICAgc2Vzc2lvbiAmJiBzZXNzaW9uLnVzZXIgIT09bnVsbCAmJiA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG9cIj48c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC00eGwgXCI+T0/ri5jsnZgg65Ox6riJ7J2AIFwi7J2867CYIO2ajOybkFwiIOyeheuLiOuLpC48L3NwYW4+IDwvZGl2PlxyXG4gICAgICAgfVxyXG4gICAgICBcclxuICAgICAgICB7c2Vzc2lvbiAmJiBzZXNzaW9uLnVzZXIgPyA8YnV0dG9uIGNsYXNzTmFtZT1cImJnLW9yYW5nZS00MDAgcC02IHRleHQtd2hpdGUgcm91bmRlZC1tZFwiPuuhnOq3uOyVhOybgzwvYnV0dG9uPiBcclxuICAgICAgICA6IFxyXG4gICAgIFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgIDxMaW5rIGhyZWY9XCIvbG9naW5cIj7thrXtlanroZzqt7jsnbg8L0xpbms+XHJcbiAgICAgICAgIDxMaW5rIGhyZWY9XCIvcmVnaXN0ZXJcIj4gPHA+7ZqM7JuQ6rCA7J6FPC9wPjwvTGluaz5cclxuICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1heC13LTd4bCBqdXN0aWZ5LWFyb3VuZFwiPlxyXG4gICAgICAgIHsvKiA8YnV0dG9uIG9uQ2xpY2s9eygpPT57c2lnbkluKCdrYWthbycpfX0+7Lm07Lm07Jik7YahPC9idXR0b24+IFxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCk9PntzaWduSW4oJ2dpdGh1YicpfX0+6rmD7ZeI67iMPC9idXR0b24+IFxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCk9PntzaWduSW4oJ25hdmVyJyl9fT7rhKTsnbTrsoQ8L2J1dHRvbj4gXHJcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKT0+e3NpZ25JbignZ29vZ2xlJyl9fT7qtazquIA8L2J1dHRvbj4gICovfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgPC8+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHsvKiDsu6TsiqTthYAg66eI7J207KeVIO2VmOuKlOuwqeuyleydgCDtlajsiJjslYjsl5AgJ+ybkO2VmOuKlCDsgqzsnbTtirgg7J6F66ClJyAqL31cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG4iXSwibmFtZXMiOlsiTGluayIsImdldFNlcnZlclNlc3Npb24iLCJhdXRoT3B0aW9ucyIsIkxvZ2luIiwic2Vzc2lvbiIsInJlZGlyZWN0VG8iLCJzZXNzaW9uU3RvcmFnZSIsInNldEl0ZW0iLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJ1c2VyIiwicCIsIm5hbWUiLCJidXR0b24iLCJkaXYiLCJjbGFzc05hbWUiLCJsZXZlbCIsInNwYW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./app/components/login.tsx\n");

/***/ }),

/***/ "(rsc)/./app/layout.tsx":
/*!************************!*\
  !*** ./app/layout.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RootLayout),\n/* harmony export */   metadata: () => (/* binding */ metadata)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/font/google/target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"} */ \"(rsc)/./node_modules/next/font/google/target.css?{\\\"path\\\":\\\"app\\\\\\\\layout.tsx\\\",\\\"import\\\":\\\"Inter\\\",\\\"arguments\\\":[{\\\"subsets\\\":[\\\"latin\\\"]}],\\\"variableName\\\":\\\"inter\\\"}\");\n/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals.css */ \"(rsc)/./app/globals.css\");\n/* harmony import */ var _components_login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/login */ \"(rsc)/./app/components/login.tsx\");\n/* harmony import */ var _session__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./session */ \"(rsc)/./app/session.tsx\");\n\n\n\n\n\nconst metadata = {\n    title: \"Create Next App\",\n    description: \"Generated by create next app\",\n    icons: {\n        icon: \"/favicon.ico\"\n    }\n};\nasync function RootLayout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"html\", {\n        lang: \"en\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n            className: (next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_4___default().className),\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_session__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_login__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                        fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\layout.tsx\",\n                        lineNumber: 32,\n                        columnNumber: 11\n                    }, this),\n                    children\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\layout.tsx\",\n                lineNumber: 31,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\layout.tsx\",\n            lineNumber: 30,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\layout.tsx\",\n        lineNumber: 28,\n        columnNumber: 5\n    }, this);\n} // 전체를 읽는 페이지\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvbGF5b3V0LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBU01BO0FBUGdCO0FBQ2dCO0FBSUg7QUFJNUIsTUFBTUcsV0FBcUI7SUFDaENDLE9BQU87SUFDUEMsYUFBYTtJQUNiQyxPQUFPO1FBQ0xDLE1BQU07SUFDUjtBQUNGLEVBQUM7QUFFYyxlQUFlQyxXQUFXLEVBQ3ZDQyxRQUFRLEVBR1Q7SUFHQyxxQkFDRSw4REFBQ0M7UUFBS0MsTUFBSztrQkFFVCw0RUFBQ0M7WUFBS0MsV0FBV2IsMkpBQWU7c0JBQzlCLDRFQUFDRSxnREFBV0E7O2tDQUNWLDhEQUFDRCx5REFBS0E7Ozs7O29CQUNMUTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLWCxFQUVBLGFBQWEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9sYXlvdXQudHN4Pzk5ODgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBNZXRhZGF0YSB9IGZyb20gJ25leHQnXG5pbXBvcnQgeyBJbnRlciB9IGZyb20gJ25leHQvZm9udC9nb29nbGUnXG5pbXBvcnQgJy4vZ2xvYmFscy5jc3MnXG5pbXBvcnQgTG9naW4gZnJvbSAnLi9jb21wb25lbnRzL2xvZ2luJ1xuaW1wb3J0IHsgZ2V0U2VydmVyU2Vzc2lvbiB9IGZyb20gJ25leHQtYXV0aCdcbmltcG9ydCB7IGF1dGhPcHRpb25zIH0gZnJvbSAnLi9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlJ1xuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xuaW1wb3J0IEF1dGhTZXNzaW9uIGZyb20gJy4vc2Vzc2lvbidcblxuY29uc3QgaW50ZXIgPSBJbnRlcih7IHN1YnNldHM6IFsnbGF0aW4nXSB9KVxuXG5leHBvcnQgY29uc3QgbWV0YWRhdGE6IE1ldGFkYXRhID0ge1xuICB0aXRsZTogJ0NyZWF0ZSBOZXh0IEFwcCcsXG4gIGRlc2NyaXB0aW9uOiAnR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcCcsXG4gIGljb25zOiB7XG4gICAgaWNvbjogXCIvZmF2aWNvbi5pY29cIlxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIFJvb3RMYXlvdXQoe1xuICBjaGlsZHJlbixcbn06IHtcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZVxufSkge1xuXG5cbiAgcmV0dXJuIChcbiAgICA8aHRtbCBsYW5nPVwiZW5cIj5cblxuICAgICAgPGJvZHkgY2xhc3NOYW1lPXtpbnRlci5jbGFzc05hbWV9PlxuICAgICAgICA8QXV0aFNlc3Npb24+XG4gICAgICAgICAgPExvZ2luLz5cbiAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIDwvQXV0aFNlc3Npb24+XG4gICAgICA8L2JvZHk+XG4gICAgPC9odG1sPlxuICApXG59XG5cbi8vIOyghOyytOulvCDsnb3ripQg7Y6Y7J207KeAIl0sIm5hbWVzIjpbImludGVyIiwiTG9naW4iLCJBdXRoU2Vzc2lvbiIsIm1ldGFkYXRhIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImljb25zIiwiaWNvbiIsIlJvb3RMYXlvdXQiLCJjaGlsZHJlbiIsImh0bWwiLCJsYW5nIiwiYm9keSIsImNsYXNzTmFtZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/layout.tsx\n");

/***/ }),

/***/ "(rsc)/./app/not-found.tsx":
/*!***************************!*\
  !*** ./app/not-found.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ NotFound)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/headers */ \"(rsc)/./node_modules/next/headers.js\");\n/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_headers__WEBPACK_IMPORTED_MODULE_1__);\n\n\nasync function NotFound() {\n    const headerList = (0,next_headers__WEBPACK_IMPORTED_MODULE_1__.headers)();\n    const domain = headerList.get(\"referer\");\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n            children: [\n                \" \",\n                domain,\n                \"은 없는 페이지 입니다.\"\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\not-found.tsx\",\n            lineNumber: 13,\n            columnNumber: 9\n        }, this)\n    }, void 0, false);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvbm90LWZvdW5kLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBc0M7QUFJdkIsZUFBZUM7SUFFMUIsTUFBTUMsYUFBYUYscURBQU9BO0lBQzFCLE1BQU1HLFNBQVNELFdBQVdFLEdBQUcsQ0FBQztJQUU5QixxQkFDSTtrQkFFQSw0RUFBQ0M7O2dCQUFFO2dCQUFFRjtnQkFBTzs7Ozs7Ozs7QUFHcEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9ub3QtZm91bmQudHN4PzVjODAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaGVhZGVycyB9IGZyb20gJ25leHQvaGVhZGVycydcclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gTm90Rm91bmQoKXtcclxuICAgIFxyXG4gICAgY29uc3QgaGVhZGVyTGlzdCA9IGhlYWRlcnMoKTtcclxuICAgIGNvbnN0IGRvbWFpbiA9IGhlYWRlckxpc3QuZ2V0KCdyZWZlcmVyJyk7XHJcbiAgICBcclxuICAgIHJldHVybihcclxuICAgICAgICA8PlxyXG4gICAgICAgXHJcbiAgICAgICAgPHA+IHtkb21haW597J2AIOyXhuuKlCDtjpjsnbTsp4Ag7J6F64uI64ukLjwvcD5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufSJdLCJuYW1lcyI6WyJoZWFkZXJzIiwiTm90Rm91bmQiLCJoZWFkZXJMaXN0IiwiZG9tYWluIiwiZ2V0IiwicCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/not-found.tsx\n");

/***/ }),

/***/ "(rsc)/./app/session.tsx":
/*!*************************!*\
  !*** ./app/session.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/build/webpack/loaders/next-flight-loader/module-proxy */ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js");

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\Students\Locker\이정석\Nextjs\board\app\session.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ "(rsc)/./db.js":
/*!***************!*\
  !*** ./db.js ***!
  \***************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"(rsc)/./node_modules/mysql2/promise.js\");\n\nconst connectDB = mysql2_promise__WEBPACK_IMPORTED_MODULE_0__.createPool({\n    host: \"localhost\",\n    user: \"root\",\n    password: \"wjdtjr3088\",\n    database: \"board\"\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDB);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9kYi5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFnQztBQUVoQyxNQUFNQyxZQUFZRCxzREFBYSxDQUFDO0lBQzVCRyxNQUFNO0lBQ05DLE1BQU07SUFDTkMsVUFBVTtJQUNWQyxVQUFVO0FBQ2Q7QUFFQSxpRUFBZUwsU0FBU0EsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLy4vZGIuanM/NTY2NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGIgZnJvbSAnbXlzcWwyL3Byb21pc2UnO1xyXG5cclxuY29uc3QgY29ubmVjdERCID0gZGIuY3JlYXRlUG9vbCh7XHJcbiAgICBob3N0OiAnbG9jYWxob3N0JyxcclxuICAgIHVzZXI6ICdyb290JyxcclxuICAgIHBhc3N3b3JkOiAnd2pkdGpyMzA4OCcsXHJcbiAgICBkYXRhYmFzZTogJ2JvYXJkJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3REQiJdLCJuYW1lcyI6WyJkYiIsImNvbm5lY3REQiIsImNyZWF0ZVBvb2wiLCJob3N0IiwidXNlciIsInBhc3N3b3JkIiwiZGF0YWJhc2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./db.js\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__ ***!
  \**********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/lib/metadata/get-metadata-route */ \"(rsc)/./node_modules/next/dist/lib/metadata/get-metadata-route.js\");\n/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);\n  \n\n  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {\n    const imageData = {\"type\":\"image/x-icon\",\"sizes\":\"16x16\"}\n    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(\".\", props.params, \"favicon.ico\")\n\n    return [{\n      ...imageData,\n      url: imageUrl + \"\",\n    }]\n  });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LW1ldGFkYXRhLWltYWdlLWxvYWRlci5qcz90eXBlPWZhdmljb24mc2VnbWVudD0mYmFzZVBhdGg9JnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMhLi9hcHAvZmF2aWNvbi5pY28/X19uZXh0X21ldGFkYXRhX18iLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsRUFBaUY7O0FBRWpGLEVBQUUsaUVBQWU7QUFDakIsdUJBQXVCO0FBQ3ZCLHFCQUFxQiw4RkFBbUI7O0FBRXhDO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLy4vYXBwL2Zhdmljb24uaWNvP2I0YTUiXSwic291cmNlc0NvbnRlbnQiOlsiICBpbXBvcnQgeyBmaWxsTWV0YWRhdGFTZWdtZW50IH0gZnJvbSAnbmV4dC9kaXN0L2xpYi9tZXRhZGF0YS9nZXQtbWV0YWRhdGEtcm91dGUnXG5cbiAgZXhwb3J0IGRlZmF1bHQgKHByb3BzKSA9PiB7XG4gICAgY29uc3QgaW1hZ2VEYXRhID0ge1widHlwZVwiOlwiaW1hZ2UveC1pY29uXCIsXCJzaXplc1wiOlwiMTZ4MTZcIn1cbiAgICBjb25zdCBpbWFnZVVybCA9IGZpbGxNZXRhZGF0YVNlZ21lbnQoXCIuXCIsIHByb3BzLnBhcmFtcywgXCJmYXZpY29uLmljb1wiKVxuXG4gICAgcmV0dXJuIFt7XG4gICAgICAuLi5pbWFnZURhdGEsXG4gICAgICB1cmw6IGltYWdlVXJsICsgXCJcIixcbiAgICB9XVxuICB9Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-metadata-image-loader.js?type=favicon&segment=&basePath=&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/mysql2","vendor-chunks/iconv-lite","vendor-chunks/long","vendor-chunks/named-placeholders","vendor-chunks/denque","vendor-chunks/is-property","vendor-chunks/sqlstring","vendor-chunks/seq-queue","vendor-chunks/generate-function","vendor-chunks/safer-buffer","vendor-chunks/next-auth","vendor-chunks/jose","vendor-chunks/openid-client","vendor-chunks/@babel","vendor-chunks/oauth","vendor-chunks/preact","vendor-chunks/preact-render-to-string","vendor-chunks/uuid","vendor-chunks/yallist","vendor-chunks/lru-cache","vendor-chunks/cookie","vendor-chunks/oidc-token-hash","vendor-chunks/@panva"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fnot-found&page=%2Fnot-found&appPaths=&pagePath=private-next-app-dir%2Fnot-found.tsx&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();