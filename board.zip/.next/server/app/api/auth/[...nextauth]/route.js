/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/auth/[...nextauth]/route";
exports.ids = ["app/api/auth/[...nextauth]/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$":
/*!****************************************************!*\
  !*** ./node_modules/mysql2/lib/ sync ^cardinal.*$ ***!
  \****************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("bcrypt");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist\\client\\components\\action-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist\\client\\components\\action-async-storage.external.js");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist\\client\\components\\request-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist\\client\\components\\request-async-storage.external.js");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!*********************************************************************************************!*\
  !*** external "next/dist\\client\\components\\static-generation-async-storage.external.js" ***!
  \*********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist\\client\\components\\static-generation-async-storage.external.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   headerHooks: () => (/* binding */ headerHooks),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),\n/* harmony export */   staticGenerationBailout: () => (/* binding */ staticGenerationBailout)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var D_Students_Locker_Nextjs_board_app_api_auth_nextauth_route_ts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/api/auth/[...nextauth]/route.ts */ \"(rsc)/./app/api/auth/[...nextauth]/route.ts\");\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/auth/[...nextauth]/route\",\n        pathname: \"/api/auth/[...nextauth]\",\n        filename: \"route\",\n        bundlePath: \"app/api/auth/[...nextauth]/route\"\n    },\n    resolvedPagePath: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\api\\\\auth\\\\[...nextauth]\\\\route.ts\",\n    nextConfigOutput,\n    userland: D_Students_Locker_Nextjs_board_app_api_auth_nextauth_route_ts__WEBPACK_IMPORTED_MODULE_2__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks, headerHooks, staticGenerationBailout } = routeModule;\nconst originalPathname = \"/api/auth/[...nextauth]/route\";\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZhdXRoJTJGJTVCLi4ubmV4dGF1dGglNUQlMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRmF1dGglMkYlNUIuLi5uZXh0YXV0aCU1RCUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRmF1dGglMkYlNUIuLi5uZXh0YXV0aCU1RCUyRnJvdXRlLnRzJmFwcERpcj1EJTNBJTVDU3R1ZGVudHMlNUNMb2NrZXIlNUMlRUMlOUQlQjQlRUMlQTAlOTUlRUMlODQlOUQlNUNOZXh0anMlNUNib2FyZCU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQytDO0FBQzlHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnSEFBbUI7QUFDM0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsdUdBQXVHO0FBQy9HO0FBQ2lKOztBQUVqSiIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLz83ODNlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxhcGlcXFxcYXV0aFxcXFxbLi4ubmV4dGF1dGhdXFxcXHJvdXRlLnRzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9hdXRoL1suLi5uZXh0YXV0aF0vcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9hdXRoL1suLi5uZXh0YXV0aF1cIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxhcGlcXFxcYXV0aFxcXFxbLi4ubmV4dGF1dGhdXFxcXHJvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIGhlYWRlckhvb2tzLCBzdGF0aWNHZW5lcmF0aW9uQmFpbG91dCB9ID0gcm91dGVNb2R1bGU7XG5jb25zdCBvcmlnaW5hbFBhdGhuYW1lID0gXCIvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZVwiO1xuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBoZWFkZXJIb29rcywgc3RhdGljR2VuZXJhdGlvbkJhaWxvdXQsIG9yaWdpbmFsUGF0aG5hbWUsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/auth/[...nextauth]/route.ts":
/*!*********************************************!*\
  !*** ./app/api/auth/[...nextauth]/route.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ handler),\n/* harmony export */   POST: () => (/* binding */ handler),\n/* harmony export */   authOptions: () => (/* binding */ authOptions)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"(rsc)/./node_modules/next-auth/index.js\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/github */ \"(rsc)/./node_modules/next-auth/providers/github.js\");\n/* harmony import */ var next_auth_providers_kakao__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth/providers/kakao */ \"(rsc)/./node_modules/next-auth/providers/kakao.js\");\n/* harmony import */ var next_auth_providers_naver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-auth/providers/naver */ \"(rsc)/./node_modules/next-auth/providers/naver.js\");\n/* harmony import */ var next_auth_providers_google__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next-auth/providers/google */ \"(rsc)/./node_modules/next-auth/providers/google.js\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next-auth/providers/credentials */ \"(rsc)/./node_modules/next-auth/providers/credentials.js\");\n/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/db */ \"(rsc)/./db.js\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_7__);\n\n\n\n\n\n\n\n\nconst authOptions = {\n    providers: [\n        (0,next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__[\"default\"])({\n            clientId: `${process.env.GITHUB_ID}`,\n            clientSecret: `${process.env.GITHUB_PW}` //env로 변경해서 써주기\n        }),\n        (0,next_auth_providers_kakao__WEBPACK_IMPORTED_MODULE_2__[\"default\"])({\n            clientId: `${process.env.KAKAO_ID}`,\n            clientSecret: `${process.env.KAKAO_PW}` // 비밀번호는 카카오로그인 -> 보안 ->코드생성 후 -> 코드 복사해서 붙이기\n        }),\n        (0,next_auth_providers_naver__WEBPACK_IMPORTED_MODULE_3__[\"default\"])({\n            clientId: `${process.env.NAVER_ID}`,\n            clientSecret: `${process.env.NAVER_PW}` // 비밀번호는 카카오로그인 -> 보안 ->코드생성 후 -> 코드 복사해서 붙이기\n        }),\n        (0,next_auth_providers_google__WEBPACK_IMPORTED_MODULE_4__[\"default\"])({\n            clientId: `${process.env.GOOGLE_ID}`,\n            clientSecret: `${process.env.GOOGLE_PW}`\n        }),\n        (0,next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_5__[\"default\"])({\n            name: \"Credentials\",\n            credentials: {\n                email: {\n                    label: \"email\",\n                    type: \"text\",\n                    placeholder: \"email을 입력하세요\"\n                },\n                password: {\n                    label: \"Password\",\n                    type: \"password\"\n                }\n            },\n            async authorize (credentials) {\n                try {\n                    const [results] = await _db__WEBPACK_IMPORTED_MODULE_6__[\"default\"].query(\"select * from board.member where email = ?\", [\n                        credentials?.email\n                    ]);\n                    console.log(results[0].email);\n                    const userResult = results[0];\n                    if (!credentials || !credentials.email || !credentials.password) {\n                        return null;\n                    }\n                    if (!results[0].email || !userResult.password) {\n                        console.log(\"해당 사용자가 없습니다.\");\n                        return null;\n                    }\n                    const pwCheck = await bcrypt__WEBPACK_IMPORTED_MODULE_7___default().compare(credentials.password, results[0].password);\n                    if (!pwCheck) {\n                        console.log(\"비밀번호 에러\");\n                        return null;\n                    }\n                    const user = {\n                        id: userResult.id,\n                        name: userResult.name,\n                        email: userResult.email,\n                        level: userResult.level\n                    };\n                    return user;\n                } catch (error) {\n                    return null;\n                }\n            }\n        })\n    ],\n    // pages: {\n    //     signIn: '/login'\n    // },\n    // jwt 만료일 설정\n    session: {\n        strategy: \"jwt\",\n        maxAge: 24 * 60 * 60\n    },\n    // jwt 만들 때 실행 되는 코드 ( 토큰 발급 )\n    callbacks: {\n        jwt: async ({ token, user })=>{\n            if (user) {\n                token.user = {\n                    name: user.name,\n                    email: user.email,\n                    level: user.level\n                };\n            }\n            return token;\n        },\n        session: async ({ session, token })=>{\n            session.user = token.user;\n            return session;\n        }\n    },\n    secret: `${process.env.SECRET}`\n};\nconst handler = next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions);\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQWlDO0FBQ2U7QUFDTztBQUNBO0FBQ0U7QUFDUztBQUM1QztBQUNNO0FBZ0JyQixNQUFNUSxjQUFtQjtJQUM1QkMsV0FBWTtRQUNSUixzRUFBTUEsQ0FBQztZQUNIUyxVQUFTLENBQUMsRUFBRUMsUUFBUUMsR0FBRyxDQUFDQyxTQUFTLENBQUMsQ0FBQztZQUNuQ0MsY0FBYyxDQUFDLEVBQUVILFFBQVFDLEdBQUcsQ0FBQ0csU0FBUyxDQUFDLENBQUMsQ0FBUyxlQUFlO1FBQ3BFO1FBQ0FiLHFFQUFhQSxDQUFDO1lBQ1ZRLFVBQVMsQ0FBQyxFQUFFQyxRQUFRQyxHQUFHLENBQUNJLFFBQVEsQ0FBQyxDQUFDO1lBQ2xDRixjQUFjLENBQUMsRUFBRUgsUUFBUUMsR0FBRyxDQUFDSyxRQUFRLENBQUMsQ0FBQyxDQUEwQiw2Q0FBNkM7UUFDbEg7UUFDQWQscUVBQWFBLENBQUM7WUFDVk8sVUFBUyxDQUFDLEVBQUVDLFFBQVFDLEdBQUcsQ0FBQ00sUUFBUSxDQUFDLENBQUM7WUFDbENKLGNBQWMsQ0FBQyxFQUFFSCxRQUFRQyxHQUFHLENBQUNPLFFBQVEsQ0FBQyxDQUFDLENBQW9DLDZDQUE2QztRQUM1SDtRQUNBZixzRUFBY0EsQ0FBQztZQUNYTSxVQUFTLENBQUMsRUFBRUMsUUFBUUMsR0FBRyxDQUFDUSxTQUFTLENBQUMsQ0FBQztZQUNuQ04sY0FBYSxDQUFDLEVBQUVILFFBQVFDLEdBQUcsQ0FBQ1MsU0FBUyxDQUFDLENBQUM7UUFDM0M7UUFDQWhCLDJFQUFtQkEsQ0FBQztZQUVoQmlCLE1BQU07WUFDTkMsYUFBYTtnQkFDWEMsT0FBTztvQkFBRUMsT0FBTztvQkFBU0MsTUFBTTtvQkFBUUMsYUFBYTtnQkFBZTtnQkFDbkVDLFVBQVU7b0JBQUVILE9BQU87b0JBQVlDLE1BQU07Z0JBQVc7WUFDbEQ7WUFDQSxNQUFNRyxXQUFVTixXQUFXO2dCQUV2QixJQUFHO29CQUNDLE1BQU0sQ0FBQ08sUUFBUSxHQUFHLE1BQU14QiwyQ0FBRUEsQ0FBQ3lCLEtBQUssQ0FBa0IsOENBQThDO3dCQUFDUixhQUFhQztxQkFBTTtvQkFDcEhRLFFBQVFDLEdBQUcsQ0FBQ0gsT0FBTyxDQUFDLEVBQUUsQ0FBQ04sS0FBSztvQkFDNUIsTUFBTVUsYUFBYUosT0FBTyxDQUFDLEVBQUU7b0JBQzdCLElBQUcsQ0FBQ1AsZUFBZSxDQUFDQSxZQUFZQyxLQUFLLElBQUksQ0FBQ0QsWUFBWUssUUFBUSxFQUFDO3dCQUMzRCxPQUFPO29CQUNYO29CQUNBLElBQUcsQ0FBQ0UsT0FBTyxDQUFDLEVBQUUsQ0FBQ04sS0FBSyxJQUFJLENBQUNVLFdBQVdOLFFBQVEsRUFBQzt3QkFDekNJLFFBQVFDLEdBQUcsQ0FBQzt3QkFDWixPQUFPO29CQUNYO29CQUNBLE1BQU1FLFVBQVUsTUFBTTVCLHFEQUFjLENBQUNnQixZQUFZSyxRQUFRLEVBQUdFLE9BQU8sQ0FBQyxFQUFFLENBQUNGLFFBQVE7b0JBRS9FLElBQUcsQ0FBQ08sU0FBUTt3QkFDUkgsUUFBUUMsR0FBRyxDQUFDO3dCQUNaLE9BQU87b0JBQ1g7b0JBQ0EsTUFBTUksT0FBWTt3QkFDZEMsSUFBS0osV0FBV0ksRUFBRTt3QkFDbEJoQixNQUFNWSxXQUFXWixJQUFJO3dCQUNyQkUsT0FBT1UsV0FBV1YsS0FBSzt3QkFDdkJlLE9BQU9MLFdBQVdLLEtBQUs7b0JBQzNCO29CQUNBLE9BQU9GO2dCQUNYLEVBQUMsT0FBTUcsT0FBTTtvQkFDVCxPQUFPO2dCQUNYO1lBQ0o7UUFBQztLQUNSO0lBQ0QsV0FBVztJQUNYLHVCQUF1QjtJQUN2QixLQUFLO0lBRUwsYUFBYTtJQUNiQyxTQUFVO1FBQ05DLFVBQVc7UUFDWEMsUUFBUSxLQUFLLEtBQUs7SUFDdEI7SUFDQSw4QkFBOEI7SUFDOUJDLFdBQVk7UUFDUkMsS0FBSyxPQUFPLEVBQUNDLEtBQUssRUFBRVQsSUFBSSxFQUE0QjtZQUNoRCxJQUFHQSxNQUFLO2dCQUNKUyxNQUFNVCxJQUFJLEdBQUU7b0JBQ1JmLE1BQU1lLEtBQUtmLElBQUk7b0JBQ2ZFLE9BQU9hLEtBQUtiLEtBQUs7b0JBQ2pCZSxPQUFRRixLQUFLRSxLQUFLO2dCQUN0QjtZQUNKO1lBQ0EsT0FBT087UUFDWDtRQUNBTCxTQUFVLE9BQU8sRUFBQ0EsT0FBTyxFQUFDSyxLQUFLLEVBQXdDO1lBQ25FTCxRQUFRSixJQUFJLEdBQUdTLE1BQU1ULElBQUk7WUFDekIsT0FBT0k7UUFDWDtJQUNKO0lBQ0FNLFFBQVEsQ0FBQyxFQUFFcEMsUUFBUUMsR0FBRyxDQUFDb0MsTUFBTSxDQUFDLENBQUM7QUFFbkMsRUFBRTtBQUdGLE1BQU1DLFVBQVVqRCxnREFBUUEsQ0FBQ1E7QUFDZ0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib2FyZC8uL2FwcC9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlLnRzP2M4YTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5leHRBdXRoIGZyb20gXCJuZXh0LWF1dGhcIjtcclxuaW1wb3J0IEdpdGh1YiBmcm9tIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9naXRodWJcIjtcclxuaW1wb3J0IEtha2FvUHJvdmlkZXIgZnJvbSAgXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2tha2FvXCI7XHJcbmltcG9ydCBOYXZlclByb3ZpZGVyIGZyb20gIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9uYXZlclwiO1xyXG5pbXBvcnQgR29vZ2xlUHJvdmlkZXIgZnJvbSAgXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2dvb2dsZVwiO1xyXG5pbXBvcnQgQ3JlZGVudGlhbHNQcm92aWRlciBmcm9tIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9jcmVkZW50aWFsc1wiO1xyXG5pbXBvcnQgZGIgZnJvbSAnQC9kYic7XHJcbmltcG9ydCBiY3J5cHQgZnJvbSAnYmNyeXB0JztcclxuaW1wb3J0IHsgUm93RGF0YVBhY2tldCB9IGZyb20gXCJteXNxbDJcIjtcclxuaW1wb3J0IHsgSldUIH0gZnJvbSBcIm5leHQtYXV0aC9qd3RcIjtcclxuaW1wb3J0IHsgU2Vzc2lvbiB9IGZyb20gXCJuZXh0LWF1dGhcIjtcclxuXHJcbmludGVyZmFjZSBVc2Vye1xyXG4gICAgaWQ6IHN0cmluZztcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIGVtYWlsOiBzdHJpbmc7XHJcbiAgICBsZXZlbDogc3RyaW5nXHJcbn1cclxuXHJcbmludGVyZmFjZSBDdXN0b21TZXNzaW9uIGV4dGVuZHMgU2Vzc2lvbntcclxuICAgIHVzZXI/OiBVc2VyXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBhdXRoT3B0aW9ucyA6YW55ID0ge1xyXG4gICAgcHJvdmlkZXJzIDogW1xyXG4gICAgICAgIEdpdGh1Yih7XHJcbiAgICAgICAgICAgIGNsaWVudElkOmAke3Byb2Nlc3MuZW52LkdJVEhVQl9JRH1gLFxyXG4gICAgICAgICAgICBjbGllbnRTZWNyZXQ6IGAke3Byb2Nlc3MuZW52LkdJVEhVQl9QV31gICAgICAgICAgLy9lbnbroZwg67OA6rK97ZW07IScIOyNqOyjvOq4sFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIEtha2FvUHJvdmlkZXIoe1xyXG4gICAgICAgICAgICBjbGllbnRJZDpgJHtwcm9jZXNzLmVudi5LQUtBT19JRH1gLCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8v7Lm07Lm07Jik7YahIOqwnOuwnOyekCDslbEg7ISk7KCVLT4g7JWxIO2CpCAtPiBSZXN0IEFQSSBLRVnsnoXroKVcclxuICAgICAgICAgICAgY2xpZW50U2VjcmV0OiBgJHtwcm9jZXNzLmVudi5LQUtBT19QV31gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDruYTrsIDrsojtmLjripQg7Lm07Lm07Jik66Gc6re47J24IC0+IOuztOyViCAtPuy9lOuTnOyDneyEsSDtm4QgLT4g7L2U65OcIOuzteyCrO2VtOyEnCDrtpnsnbTquLBcclxuICAgICAgICB9KSxcclxuICAgICAgICBOYXZlclByb3ZpZGVyKHtcclxuICAgICAgICAgICAgY2xpZW50SWQ6YCR7cHJvY2Vzcy5lbnYuTkFWRVJfSUR9YCwgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+y5tOy5tOyYpO2GoSDqsJzrsJzsnpAg7JWxIOyEpOyglS0+IOyVsSDtgqQgLT4gUmVzdCBBUEkgS0VZ7J6F66ClXHJcbiAgICAgICAgICAgIGNsaWVudFNlY3JldDogYCR7cHJvY2Vzcy5lbnYuTkFWRVJfUFd9YCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIOu5hOuwgOuyiO2YuOuKlCDsubTsubTsmKTroZzqt7jsnbggLT4g67O07JWIIC0+7L2U65Oc7IOd7ISxIO2bhCAtPiDsvZTrk5wg67O17IKs7ZW07IScIOu2meydtOq4sFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIEdvb2dsZVByb3ZpZGVyKHtcclxuICAgICAgICAgICAgY2xpZW50SWQ6YCR7cHJvY2Vzcy5lbnYuR09PR0xFX0lEfWAsICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgY2xpZW50U2VjcmV0OmAke3Byb2Nlc3MuZW52LkdPT0dMRV9QV31gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIENyZWRlbnRpYWxzUHJvdmlkZXIoe1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAgIG5hbWU6IFwiQ3JlZGVudGlhbHNcIixcclxuICAgICAgICAgICAgY3JlZGVudGlhbHM6IHtcclxuICAgICAgICAgICAgICBlbWFpbDogeyBsYWJlbDogXCJlbWFpbFwiLCB0eXBlOiBcInRleHRcIiwgcGxhY2Vob2xkZXI6IFwiZW1haWzsnYQg7J6F66Cl7ZWY7IS47JqUXCIgfSxcclxuICAgICAgICAgICAgICBwYXNzd29yZDogeyBsYWJlbDogXCJQYXNzd29yZFwiLCB0eXBlOiBcInBhc3N3b3JkXCIgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhc3luYyBhdXRob3JpemUoY3JlZGVudGlhbHMpIDogUHJvbWlzZTxVc2VyIHwgbnVsbD57XHJcblxyXG4gICAgICAgICAgICAgICAgdHJ5e1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IFtyZXN1bHRzXSA9IGF3YWl0IGRiLnF1ZXJ5PFJvd0RhdGFQYWNrZXRbXT4oJ3NlbGVjdCAqIGZyb20gYm9hcmQubWVtYmVyIHdoZXJlIGVtYWlsID0gPycsIFtjcmVkZW50aWFscz8uZW1haWxdKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHRzWzBdLmVtYWlsKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzZXJSZXN1bHQgPSByZXN1bHRzWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgaWYoIWNyZWRlbnRpYWxzIHx8ICFjcmVkZW50aWFscy5lbWFpbCB8fCAhY3JlZGVudGlhbHMucGFzc3dvcmQpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZighcmVzdWx0c1swXS5lbWFpbCB8fCAhdXNlclJlc3VsdC5wYXNzd29yZCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi7ZW064u5IOyCrOyaqeyekOqwgCDsl4bsirXri4jri6QuXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBwd0NoZWNrID0gYXdhaXQgYmNyeXB0LmNvbXBhcmUoY3JlZGVudGlhbHMucGFzc3dvcmQgLCByZXN1bHRzWzBdLnBhc3N3b3JkKTtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBpZighcHdDaGVjayl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi67mE67CA67KI7Zi4IOyXkOufrFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VyOlVzZXIgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkIDogdXNlclJlc3VsdC5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogdXNlclJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogdXNlclJlc3VsdC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV2ZWw6IHVzZXJSZXN1bHQubGV2ZWxcclxuICAgICAgICAgICAgICAgICAgICB9ICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB1c2VyO1xyXG4gICAgICAgICAgICAgICAgfWNhdGNoKGVycm9yKXtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9fSlcclxuICAgIF0sXHJcbiAgICAvLyBwYWdlczoge1xyXG4gICAgLy8gICAgIHNpZ25JbjogJy9sb2dpbidcclxuICAgIC8vIH0sXHJcblxyXG4gICAgLy8gand0IOunjOujjOydvCDshKTsoJVcclxuICAgIHNlc3Npb24gOiB7XHJcbiAgICAgICAgc3RyYXRlZ3kgOiAnand0JyxcclxuICAgICAgICBtYXhBZ2U6IDI0ICogNjAgKiA2MFxyXG4gICAgfSxcclxuICAgIC8vIGp3dCDrp4zrk6Qg65WMIOyLpO2WiSDrkJjripQg7L2U65OcICgg7Yag7YGwIOuwnOq4iSApXHJcbiAgICBjYWxsYmFja3MgOiB7XHJcbiAgICAgICAgand0OiBhc3luYyAoe3Rva2VuLCB1c2VyfSA6IHt0b2tlbjpKV1QgLCB1c2VyPzpVc2VyfSk9PntcclxuICAgICAgICAgICAgaWYodXNlcil7XHJcbiAgICAgICAgICAgICAgICB0b2tlbi51c2VyID17XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICAgIGxldmVsIDogdXNlci5sZXZlbFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdG9rZW5cclxuICAgICAgICB9LFxyXG4gICAgICAgIHNlc3Npb24gOiBhc3luYyAoe3Nlc3Npb24sdG9rZW59IDoge3Nlc3Npb246IEN1c3RvbVNlc3Npb24sIHRva2VuOiBKV1R9KT0+e1xyXG4gICAgICAgICAgICBzZXNzaW9uLnVzZXIgPSB0b2tlbi51c2VyIGFzIFVzZXI7XHJcbiAgICAgICAgICAgIHJldHVybiBzZXNzaW9uXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHNlY3JldDogYCR7cHJvY2Vzcy5lbnYuU0VDUkVUfWAsIC8vand0IOyDneyEseyLnCDtlYTsmpTtlZwg67mE67CA67KI7Zi4XHJcbiAgICBcclxufTtcclxuXHJcblxyXG5jb25zdCBoYW5kbGVyID0gbmV4dEF1dGgoYXV0aE9wdGlvbnMpO1xyXG5leHBvcnQgeyBoYW5kbGVyIGFzIEdFVCwgaGFuZGxlciBhcyBQT1NUfVxyXG5cclxuXHJcbiJdLCJuYW1lcyI6WyJuZXh0QXV0aCIsIkdpdGh1YiIsIktha2FvUHJvdmlkZXIiLCJOYXZlclByb3ZpZGVyIiwiR29vZ2xlUHJvdmlkZXIiLCJDcmVkZW50aWFsc1Byb3ZpZGVyIiwiZGIiLCJiY3J5cHQiLCJhdXRoT3B0aW9ucyIsInByb3ZpZGVycyIsImNsaWVudElkIiwicHJvY2VzcyIsImVudiIsIkdJVEhVQl9JRCIsImNsaWVudFNlY3JldCIsIkdJVEhVQl9QVyIsIktBS0FPX0lEIiwiS0FLQU9fUFciLCJOQVZFUl9JRCIsIk5BVkVSX1BXIiwiR09PR0xFX0lEIiwiR09PR0xFX1BXIiwibmFtZSIsImNyZWRlbnRpYWxzIiwiZW1haWwiLCJsYWJlbCIsInR5cGUiLCJwbGFjZWhvbGRlciIsInBhc3N3b3JkIiwiYXV0aG9yaXplIiwicmVzdWx0cyIsInF1ZXJ5IiwiY29uc29sZSIsImxvZyIsInVzZXJSZXN1bHQiLCJwd0NoZWNrIiwiY29tcGFyZSIsInVzZXIiLCJpZCIsImxldmVsIiwiZXJyb3IiLCJzZXNzaW9uIiwic3RyYXRlZ3kiLCJtYXhBZ2UiLCJjYWxsYmFja3MiLCJqd3QiLCJ0b2tlbiIsInNlY3JldCIsIlNFQ1JFVCIsImhhbmRsZXIiLCJHRVQiLCJQT1NUIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/auth/[...nextauth]/route.ts\n");

/***/ }),

/***/ "(rsc)/./db.js":
/*!***************!*\
  !*** ./db.js ***!
  \***************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"(rsc)/./node_modules/mysql2/promise.js\");\n\nconst connectDB = mysql2_promise__WEBPACK_IMPORTED_MODULE_0__.createPool({\n    host: \"localhost\",\n    user: \"root\",\n    password: \"wjdtjr3088\",\n    database: \"board\"\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDB);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9kYi5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFnQztBQUVoQyxNQUFNQyxZQUFZRCxzREFBYSxDQUFDO0lBQzVCRyxNQUFNO0lBQ05DLE1BQU07SUFDTkMsVUFBVTtJQUNWQyxVQUFVO0FBQ2Q7QUFFQSxpRUFBZUwsU0FBU0EsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLy4vZGIuanM/NTY2NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGIgZnJvbSAnbXlzcWwyL3Byb21pc2UnO1xyXG5cclxuY29uc3QgY29ubmVjdERCID0gZGIuY3JlYXRlUG9vbCh7XHJcbiAgICBob3N0OiAnbG9jYWxob3N0JyxcclxuICAgIHVzZXI6ICdyb290JyxcclxuICAgIHBhc3N3b3JkOiAnd2pkdGpyMzA4OCcsXHJcbiAgICBkYXRhYmFzZTogJ2JvYXJkJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3REQiJdLCJuYW1lcyI6WyJkYiIsImNvbm5lY3REQiIsImNyZWF0ZVBvb2wiLCJob3N0IiwidXNlciIsInBhc3N3b3JkIiwiZGF0YWJhc2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./db.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mysql2","vendor-chunks/iconv-lite","vendor-chunks/next-auth","vendor-chunks/@babel","vendor-chunks/long","vendor-chunks/named-placeholders","vendor-chunks/denque","vendor-chunks/is-property","vendor-chunks/sqlstring","vendor-chunks/seq-queue","vendor-chunks/generate-function","vendor-chunks/safer-buffer","vendor-chunks/jose","vendor-chunks/openid-client","vendor-chunks/uuid","vendor-chunks/oauth","vendor-chunks/@panva","vendor-chunks/yallist","vendor-chunks/preact-render-to-string","vendor-chunks/oidc-token-hash","vendor-chunks/preact","vendor-chunks/lru-cache","vendor-chunks/cookie"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();