/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/comment/route";
exports.ids = ["app/api/comment/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$":
/*!****************************************************!*\
  !*** ./node_modules/mysql2/lib/ sync ^cardinal.*$ ***!
  \****************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/mysql2/lib sync recursive ^cardinal.*$";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fcomment%2Froute&page=%2Fapi%2Fcomment%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fcomment%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fcomment%2Froute&page=%2Fapi%2Fcomment%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fcomment%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   headerHooks: () => (/* binding */ headerHooks),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),\n/* harmony export */   staticGenerationBailout: () => (/* binding */ staticGenerationBailout)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var D_Students_Locker_Nextjs_board_app_api_comment_route_ts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/api/comment/route.ts */ \"(rsc)/./app/api/comment/route.ts\");\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/comment/route\",\n        pathname: \"/api/comment\",\n        filename: \"route\",\n        bundlePath: \"app/api/comment/route\"\n    },\n    resolvedPagePath: \"D:\\\\Students\\\\Locker\\\\이정석\\\\Nextjs\\\\board\\\\app\\\\api\\\\comment\\\\route.ts\",\n    nextConfigOutput,\n    userland: D_Students_Locker_Nextjs_board_app_api_comment_route_ts__WEBPACK_IMPORTED_MODULE_2__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks, headerHooks, staticGenerationBailout } = routeModule;\nconst originalPathname = \"/api/comment/route\";\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZjb21tZW50JTJGcm91dGUmcGFnZT0lMkZhcGklMkZjb21tZW50JTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGY29tbWVudCUyRnJvdXRlLnRzJmFwcERpcj1EJTNBJTVDU3R1ZGVudHMlNUNMb2NrZXIlNUMlRUMlOUQlQjQlRUMlQTAlOTUlRUMlODQlOUQlNUNOZXh0anMlNUNib2FyZCU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9RCUzQSU1Q1N0dWRlbnRzJTVDTG9ja2VyJTVDJUVDJTlEJUI0JUVDJUEwJTk1JUVDJTg0JTlEJTVDTmV4dGpzJTVDYm9hcmQmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ21DO0FBQ2xHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnSEFBbUI7QUFDM0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsdUdBQXVHO0FBQy9HO0FBQ2lKOztBQUVqSiIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLz8zYzc3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkQ6XFxcXFN0dWRlbnRzXFxcXExvY2tlclxcXFzsnbTsoJXshJ1cXFxcTmV4dGpzXFxcXGJvYXJkXFxcXGFwcFxcXFxhcGlcXFxcY29tbWVudFxcXFxyb3V0ZS50c1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvY29tbWVudC9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2NvbW1lbnRcIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL2NvbW1lbnQvcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJEOlxcXFxTdHVkZW50c1xcXFxMb2NrZXJcXFxc7J207KCV7ISdXFxcXE5leHRqc1xcXFxib2FyZFxcXFxhcHBcXFxcYXBpXFxcXGNvbW1lbnRcXFxccm91dGUudHNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgaGVhZGVySG9va3MsIHN0YXRpY0dlbmVyYXRpb25CYWlsb3V0IH0gPSByb3V0ZU1vZHVsZTtcbmNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9hcGkvY29tbWVudC9yb3V0ZVwiO1xuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBoZWFkZXJIb29rcywgc3RhdGljR2VuZXJhdGlvbkJhaWxvdXQsIG9yaWdpbmFsUGF0aG5hbWUsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fcomment%2Froute&page=%2Fapi%2Fcomment%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fcomment%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/comment/route.ts":
/*!**********************************!*\
  !*** ./app/api/comment/route.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/web/exports/next-response */ \"(rsc)/./node_modules/next/dist/server/web/exports/next-response.js\");\n/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/db */ \"(rsc)/./db.js\");\n\n\nconst POST = async (req)=>{\n    if (req.method === \"POST\") {\n        try {\n            const { parentid, userid, username, content } = JSON.parse(await req.text());\n            console.log(parentid, userid, username, content);\n            if (!parentid || !userid || !username || !content) {\n                return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n                    message: \"데이터가 부족합니다.\"\n                });\n            } else {\n                await _db__WEBPACK_IMPORTED_MODULE_1__[\"default\"].query(\"insert into board.comment (parentid, userid, username, content)  values(?,?,?,?)\", [\n                    parentid,\n                    userid,\n                    username,\n                    content\n                ]);\n                const [datas] = await _db__WEBPACK_IMPORTED_MODULE_1__[\"default\"].query(\"select * from board.comment where parentid = ? \", [\n                    parentid\n                ]);\n                return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n                    message: \"성공\",\n                    result: datas\n                });\n            }\n        } catch (error) {\n            return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n                error: error\n            });\n        }\n    }\n    return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n        error: \"정상적인 데이터가 아닙니다.\"\n    });\n};\nconst GET = async (req)=>{\n    if (req.method === \"GET\") {\n        try {\n            const parentid = req.nextUrl.searchParams.get(\"id\");\n            console.log(parentid);\n            const [results] = await _db__WEBPACK_IMPORTED_MODULE_1__[\"default\"].query(\"select * from board.comment where parentid = ? ORDER BY date DESC\", [\n                parentid\n            ]);\n            return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n                message: \"성공\",\n                result: results\n            });\n        } catch (error) {\n            return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n                error: error\n            });\n        }\n    } else {\n        return next_dist_server_web_exports_next_response__WEBPACK_IMPORTED_MODULE_0__[\"default\"].json({\n            error: \"정상적인 데이터가 아닙니다.\"\n        });\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2NvbW1lbnQvcm91dGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUF3RDtBQUNsQztBQVNmLE1BQU1FLE9BQU8sT0FDaEJDO0lBRUEsSUFBR0EsSUFBSUMsTUFBTSxLQUFLLFFBQU87UUFDekIsSUFBRztZQUNDLE1BQU0sRUFBRUMsUUFBUSxFQUFFQyxNQUFNLEVBQUVDLFFBQVEsRUFBRUMsT0FBTyxFQUFFLEdBQWNDLEtBQUtDLEtBQUssQ0FBQyxNQUFNUCxJQUFJUSxJQUFJO1lBQ3BGQyxRQUFRQyxHQUFHLENBQUNSLFVBQVVDLFFBQVFDLFVBQVVDO1lBRXhDLElBQUcsQ0FBQ0gsWUFBWSxDQUFDQyxVQUFVLENBQUNDLFlBQVksQ0FBQ0MsU0FBUTtnQkFDN0MsT0FBT1Isa0ZBQVlBLENBQUNjLElBQUksQ0FBQztvQkFBQ0MsU0FBUztnQkFBYTtZQUNwRCxPQUFLO2dCQUNELE1BQU1kLDJDQUFFQSxDQUFDZSxLQUFLLENBQ2Isb0ZBQW9GO29CQUFDWDtvQkFBU0M7b0JBQVFDO29CQUFVQztpQkFBUTtnQkFDekgsTUFBTSxDQUFDUyxNQUFNLEdBQUcsTUFBTWhCLDJDQUFFQSxDQUFDZSxLQUFLLENBQWtCLG1EQUFtRDtvQkFBQ1g7aUJBQVM7Z0JBQzdHLE9BQU9MLGtGQUFZQSxDQUFDYyxJQUFJLENBQUM7b0JBQUNDLFNBQVM7b0JBQU1HLFFBQVFEO2dCQUFLO1lBRTFEO1FBRUosRUFBQyxPQUFNRSxPQUFNO1lBQ1QsT0FBT25CLGtGQUFZQSxDQUFDYyxJQUFJLENBQUM7Z0JBQUNLLE9BQU9BO1lBQUs7UUFDMUM7SUFFQTtJQUNBLE9BQU9uQixrRkFBWUEsQ0FBQ2MsSUFBSSxDQUFDO1FBQUNLLE9BQU87SUFBaUI7QUFDdEQsRUFBQztBQUdNLE1BQU1DLE1BQU0sT0FDZmpCO0lBRUEsSUFBR0EsSUFBSUMsTUFBTSxLQUFLLE9BQU07UUFFcEIsSUFBRztZQUNDLE1BQU1DLFdBQVdGLElBQUlrQixPQUFPLENBQUNDLFlBQVksQ0FBQ0MsR0FBRyxDQUFDO1lBQzlDWCxRQUFRQyxHQUFHLENBQUNSO1lBRVosTUFBTSxDQUFDbUIsUUFBUSxHQUFHLE1BQU12QiwyQ0FBRUEsQ0FBQ2UsS0FBSyxDQUMvQixxRUFBb0U7Z0JBQUNYO2FBQVM7WUFDL0UsT0FBT0wsa0ZBQVlBLENBQUNjLElBQUksQ0FBQztnQkFBQ0MsU0FBUztnQkFBTUcsUUFBUU07WUFBTztRQUU1RCxFQUFDLE9BQU1MLE9BQU07WUFDVCxPQUFPbkIsa0ZBQVlBLENBQUNjLElBQUksQ0FBQztnQkFBQ0ssT0FBT0E7WUFBSztRQUMxQztJQUVKLE9BQUs7UUFDRCxPQUFPbkIsa0ZBQVlBLENBQUNjLElBQUksQ0FBQztZQUFDSyxPQUFPO1FBQWlCO0lBQ3REO0FBR0osRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLy4vYXBwL2FwaS9jb21tZW50L3JvdXRlLnRzP2EyNzYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmV4dFJlcXVlc3QsIE5leHRSZXNwb25zZSB9IGZyb20gXCJuZXh0L3NlcnZlclwiO1xyXG5pbXBvcnQgZGIgZnJvbSAnQC9kYic7XHJcbmltcG9ydCB7IFJvd0RhdGFQYWNrZXQgfSBmcm9tIFwibXlzcWwyXCI7XHJcblxyXG5pbnRlcmZhY2UgUG9zdERhdGEge1xyXG4gICAgcGFyZW50aWQ6IG51bWJlcjtcclxuICAgIHVzZXJpZCA6IHN0cmluZztcclxuICAgIHVzZXJuYW1lIDogc3RyaW5nO1xyXG4gICAgY29udGVudDogc3RyaW5nO1xyXG59XHJcbmV4cG9ydCBjb25zdCBQT1NUID0gYXN5bmMgKFxyXG4gICAgcmVxOiBOZXh0UmVxdWVzdFxyXG4pIDogUHJvbWlzZTxOZXh0UmVzcG9uc2U+ID0+e1xyXG4gICAgaWYocmVxLm1ldGhvZCA9PT0gJ1BPU1QnKXtcclxuICAgIHRyeXtcclxuICAgICAgICBjb25zdCB7IHBhcmVudGlkLCB1c2VyaWQsIHVzZXJuYW1lLCBjb250ZW50IH0gOiBQb3N0RGF0YSA9IEpTT04ucGFyc2UoYXdhaXQgcmVxLnRleHQoKSk7XHJcbiAgICAgICAgY29uc29sZS5sb2cocGFyZW50aWQsIHVzZXJpZCAsdXNlcm5hbWUsIGNvbnRlbnQpXHJcblxyXG4gICAgICAgIGlmKCFwYXJlbnRpZCB8fCAhdXNlcmlkIHx8ICF1c2VybmFtZSB8fCAhY29udGVudCl7XHJcbiAgICAgICAgICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7bWVzc2FnZTogXCLrjbDsnbTthLDqsIAg67aA7KGx7ZWp64uI64ukLlwifSlcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgYXdhaXQgZGIucXVlcnk8Um93RGF0YVBhY2tldFtdPlxyXG4gICAgICAgICAgICAoJ2luc2VydCBpbnRvIGJvYXJkLmNvbW1lbnQgKHBhcmVudGlkLCB1c2VyaWQsIHVzZXJuYW1lLCBjb250ZW50KSAgdmFsdWVzKD8sPyw/LD8pJywgW3BhcmVudGlkLHVzZXJpZCwgdXNlcm5hbWUsIGNvbnRlbnRdKVxyXG4gICAgICAgICAgICBjb25zdCBbZGF0YXNdID0gYXdhaXQgZGIucXVlcnk8Um93RGF0YVBhY2tldFtdPignc2VsZWN0ICogZnJvbSBib2FyZC5jb21tZW50IHdoZXJlIHBhcmVudGlkID0gPyAnLCBbcGFyZW50aWRdKVxyXG4gICAgICAgICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oe21lc3NhZ2U6IFwi7ISx6rO1XCIsIHJlc3VsdDogZGF0YXN9KVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgIFxyXG4gICAgfWNhdGNoKGVycm9yKXtcclxuICAgICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oe2Vycm9yOiBlcnJvcn0pXHJcbiAgICB9XHJcbiAgICAgICBcclxuICAgIH1cclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7ZXJyb3I6IFwi7KCV7IOB7KCB7J24IOuNsOydtO2EsOqwgCDslYTri5nri4jri6QuXCJ9KVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IEdFVCA9IGFzeW5jIChcclxuICAgIHJlcTpOZXh0UmVxdWVzdCBcclxuKSA6IFByb21pc2U8TmV4dFJlc3BvbnNlPiA9PntcclxuICAgIGlmKHJlcS5tZXRob2QgPT09ICdHRVQnKXtcclxuXHJcbiAgICAgICAgdHJ5e1xyXG4gICAgICAgICAgICBjb25zdCBwYXJlbnRpZCA9IHJlcS5uZXh0VXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJpZFwiKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cocGFyZW50aWQpO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgW3Jlc3VsdHNdID0gYXdhaXQgZGIucXVlcnk8Um93RGF0YVBhY2tldFtdPlxyXG4gICAgICAgICAgICAoJ3NlbGVjdCAqIGZyb20gYm9hcmQuY29tbWVudCB3aGVyZSBwYXJlbnRpZCA9ID8gT1JERVIgQlkgZGF0ZSBERVNDJyxbcGFyZW50aWRdKVxyXG4gICAgICAgICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oe21lc3NhZ2U6IFwi7ISx6rO1XCIsIHJlc3VsdDogcmVzdWx0c30pXHJcblxyXG4gICAgICAgIH1jYXRjaChlcnJvcil7XHJcbiAgICAgICAgICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7ZXJyb3I6IGVycm9yfSlcclxuICAgICAgICB9XHJcblxyXG4gICAgfWVsc2V7XHJcbiAgICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHtlcnJvcjogXCLsoJXsg4HsoIHsnbgg642w7J207YSw6rCAIOyVhOuLmeuLiOuLpC5cIn0pXHJcbiAgICB9XHJcblxyXG4gICBcclxufSJdLCJuYW1lcyI6WyJOZXh0UmVzcG9uc2UiLCJkYiIsIlBPU1QiLCJyZXEiLCJtZXRob2QiLCJwYXJlbnRpZCIsInVzZXJpZCIsInVzZXJuYW1lIiwiY29udGVudCIsIkpTT04iLCJwYXJzZSIsInRleHQiLCJjb25zb2xlIiwibG9nIiwianNvbiIsIm1lc3NhZ2UiLCJxdWVyeSIsImRhdGFzIiwicmVzdWx0IiwiZXJyb3IiLCJHRVQiLCJuZXh0VXJsIiwic2VhcmNoUGFyYW1zIiwiZ2V0IiwicmVzdWx0cyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/api/comment/route.ts\n");

/***/ }),

/***/ "(rsc)/./db.js":
/*!***************!*\
  !*** ./db.js ***!
  \***************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mysql2/promise */ \"(rsc)/./node_modules/mysql2/promise.js\");\n\nconst connectDB = mysql2_promise__WEBPACK_IMPORTED_MODULE_0__.createPool({\n    host: \"localhost\",\n    user: \"root\",\n    password: \"wjdtjr3088\",\n    database: \"board\"\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDB);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9kYi5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFnQztBQUVoQyxNQUFNQyxZQUFZRCxzREFBYSxDQUFDO0lBQzVCRyxNQUFNO0lBQ05DLE1BQU07SUFDTkMsVUFBVTtJQUNWQyxVQUFVO0FBQ2Q7QUFFQSxpRUFBZUwsU0FBU0EsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL2JvYXJkLy4vZGIuanM/NTY2NSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGIgZnJvbSAnbXlzcWwyL3Byb21pc2UnO1xyXG5cclxuY29uc3QgY29ubmVjdERCID0gZGIuY3JlYXRlUG9vbCh7XHJcbiAgICBob3N0OiAnbG9jYWxob3N0JyxcclxuICAgIHVzZXI6ICdyb290JyxcclxuICAgIHBhc3N3b3JkOiAnd2pkdGpyMzA4OCcsXHJcbiAgICBkYXRhYmFzZTogJ2JvYXJkJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3REQiJdLCJuYW1lcyI6WyJkYiIsImNvbm5lY3REQiIsImNyZWF0ZVBvb2wiLCJob3N0IiwidXNlciIsInBhc3N3b3JkIiwiZGF0YWJhc2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./db.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mysql2","vendor-chunks/iconv-lite","vendor-chunks/long","vendor-chunks/named-placeholders","vendor-chunks/denque","vendor-chunks/is-property","vendor-chunks/sqlstring","vendor-chunks/seq-queue","vendor-chunks/generate-function","vendor-chunks/safer-buffer"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fcomment%2Froute&page=%2Fapi%2Fcomment%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fcomment%2Froute.ts&appDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CStudents%5CLocker%5C%EC%9D%B4%EC%A0%95%EC%84%9D%5CNextjs%5Cboard&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();